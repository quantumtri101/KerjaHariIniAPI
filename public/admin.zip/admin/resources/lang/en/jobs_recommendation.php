<?php

return [
  'title' => 'Jobs Recommendation',
  'edit' => 'Edit Jobs Recommendation',
  'add' => 'Add Jobs Recommendation',
  'detail' => 'Detail Jobs Recommendation',
];
