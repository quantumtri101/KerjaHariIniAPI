<?php

return [
  'title' => 'General Quiz',
  'edit' => 'Edit General Quiz',
  'add' => 'Add General Quiz',
  'detail' => 'Detail General Quiz',
];
