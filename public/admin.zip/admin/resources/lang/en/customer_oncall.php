<?php

return [
  'title' => 'Staff Oncall',
  'edit' => 'Edit Staff Oncall',
  'add' => 'Add Staff Oncall',
  'detail' => 'Detail Staff Oncall',
];
