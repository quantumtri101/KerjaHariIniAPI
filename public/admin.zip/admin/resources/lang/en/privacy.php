<?php

return [
  'title' => 'Privacy Policy',
  'edit' => 'Edit Privacy Policy',
  'add' => 'Add Privacy Policy',
  'detail' => 'Detail Privacy Policy',
];
