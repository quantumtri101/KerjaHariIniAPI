<?php

return [
  'title' => 'Report Monthly',
  'edit' => 'Edit Report Monthly',
  'add' => 'Add Report Monthly',
  'detail' => 'Detail Report Monthly',
];
