<?php

return [
  'title' => 'Absensi',
  'edit' => 'Edit Absensi',
  'add' => 'Add Absensi',
  'detail' => 'Detail Absensi',
  'maps' => 'Maps Absensi',
];
