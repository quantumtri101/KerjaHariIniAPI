<?php

return [
  'title' => 'Customer',
  'edit' => 'Edit Customer',
  'add' => 'Add Customer',
  'detail' => 'Detail Customer',
];
