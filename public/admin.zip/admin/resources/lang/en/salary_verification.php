<?php

return [
  'title' => 'Salary Verification',
  'edit' => 'Edit Salary Verification',
  'add' => 'Add Salary Verification',
  'detail' => 'Detail Salary Verification',
];
