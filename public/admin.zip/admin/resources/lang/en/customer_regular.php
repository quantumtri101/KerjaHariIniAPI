<?php

return [
  'title' => 'Staff Regular',
  'edit' => 'Edit Staff Regular',
  'add' => 'Add Staff Regular',
  'detail' => 'Detail Staff Regular',
];
