<?php

return [
  'title' => 'Jobs Application',
  'edit' => 'Edit Jobs Application',
  'add' => 'Add Jobs Application',
  'detail' => 'Detail Jobs Application',
];
