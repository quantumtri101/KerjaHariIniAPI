<?php

return [
  'title' => 'Category',
  'edit' => 'Edit Category',
  'add' => 'Add Category',
  'detail' => 'Detail Category',
];
