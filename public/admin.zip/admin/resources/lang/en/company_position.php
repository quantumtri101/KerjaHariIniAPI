<?php

return [
  'title' => 'Company Position',
  'edit' => 'Edit Company Position',
  'add' => 'Add Company Position',
  'detail' => 'Detail Company Position',
];
