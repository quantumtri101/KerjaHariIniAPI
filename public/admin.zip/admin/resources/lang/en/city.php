<?php

return [
  'title' => 'City',
  'edit' => 'Edit City',
  'add' => 'Add City',
];
