<?php

return [
  'title' => 'Sub Category',
  'edit' => 'Edit Sub Category',
  'add' => 'Add Sub Category',
  'detail' => 'Detail Sub Category',
];
