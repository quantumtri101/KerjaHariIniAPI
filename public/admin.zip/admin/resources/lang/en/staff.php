<?php

return [
  'title' => 'Client',
  'edit' => 'Edit Client',
  'add' => 'Add Client',
  'detail' => 'Detail Client',
];
