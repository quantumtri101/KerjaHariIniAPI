<?php

return [
  'title' => 'Communication',
  'edit' => 'Edit Communication',
  'add' => 'Add Communication',
  'detail' => 'Detail Communication',

  'email' => 'Email',
  'push_notification' => 'Push Notification',
  'all' => 'All',
  'personal' => 'Personal',
  'blast' => 'Blast',

  'empty_type' => 'Type is Empty',
  'user_not_choosen' => 'User is not Choosen yet',
  'empty_subject' => 'Subject is Empty',
  'empty_message' => 'Message is Empty',
];
