<?php

return [
  'title' => 'Event',
  'edit' => 'Edit Event',
  'add' => 'Add Event',
  'detail' => 'Detail Event',
];
