<?php

return [
  'title' => 'Recruit Form',
  'edit' => 'Edit Recruit Form',
  'add' => 'Add Recruit Form',
  'detail' => 'Detail Recruit Form',
];
