<?php

return [
  'title' => 'Banner',
  'edit' => 'Edit Banner',
  'add' => 'Add Banner',
  'detail' => 'Detail Banner',
];
