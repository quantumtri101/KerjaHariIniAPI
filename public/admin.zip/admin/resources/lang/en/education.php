<?php

return [
  'title' => 'Education',
  'edit' => 'Edit Education',
  'add' => 'Add Education',
  'detail' => 'Detail Education',
];
