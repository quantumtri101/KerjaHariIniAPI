<?php

return [
  'title' => 'Calendar',
  'edit' => 'Edit Calendar',
  'add' => 'Add Calendar',
  'detail' => 'Detail Calendar',
];
