<?php

return [
  'title' => 'Country',
  'edit' => 'Edit Country',
  'add' => 'Add Country',
];
