<?php

return [
  'title' => 'RO',
  'edit' => 'Edit RO',
  'add' => 'Add RO',
  'detail' => 'Detail RO',
];
