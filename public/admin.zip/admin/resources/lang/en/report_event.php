<?php

return [
  'title' => 'Report Event',
  'edit' => 'Edit Report Event',
  'add' => 'Add Report Event',
  'detail' => 'Detail Report Event',
];
