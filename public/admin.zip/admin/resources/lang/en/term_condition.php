<?php

return [
  'title' => 'Term & Condition',
  'edit' => 'Edit Term & Condition',
  'add' => 'Add Term & Condition',
  'detail' => 'Detail Term & Condition',
];
