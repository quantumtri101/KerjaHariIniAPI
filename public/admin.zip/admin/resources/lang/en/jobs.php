<?php

return [
  'title' => 'Jobs',
  'edit' => 'Edit Jobs',
  'add' => 'Add Jobs',
  'detail' => 'Detail Jobs',
  'choose_staff' => 'Choose Staff',
];
