<?php

return [
  'title' => 'Company',
  'edit' => 'Edit Company',
  'add' => 'Add Company',
  'detail' => 'Detail Company',
];
