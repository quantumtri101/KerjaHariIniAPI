<?php

return [
  'title' => 'Resume',
  'edit' => 'Edit Resume',
  'add' => 'Add Resume',
  'detail' => 'Detail Resume',
];
