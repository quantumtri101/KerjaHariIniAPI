<?php

return [
  'title' => 'Range Salary',
  'edit' => 'Edit Range Salary',
  'add' => 'Add Range Salary',
  'detail' => 'Detail Range Salary',
];
