<?php

return [
  'title' => 'Request Withdraw',
  'edit' => 'Edit Request Withdraw',
  'add' => 'Add Request Withdraw',
  'detail' => 'Detail Request Withdraw',
];
