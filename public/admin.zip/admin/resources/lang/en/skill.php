<?php

return [
  'title' => 'Skill',
  'edit' => 'Edit Skill',
  'add' => 'Add Skill',
  'detail' => 'Detail Skill',
];
