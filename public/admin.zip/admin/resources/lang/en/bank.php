<?php

return [
  'title' => 'Bank',
  'edit' => 'Edit Bank',
  'add' => 'Add Bank',
  'detail' => 'Detail Bank',
];
