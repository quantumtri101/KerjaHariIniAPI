<div class="row">
  <div class="col-12">
    <div class="row">
      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.id') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ $request_withdraw->id }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.user_name') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ $request_withdraw->user->name }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.bank_name') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ $request_withdraw->bank->name }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.acc_no') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ $request_withdraw->acc_no }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.acc_name') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ $request_withdraw->acc_name }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.total_amount') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="Rp. {{ number_format($request_withdraw->total_amount, 0, ',', '.') }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1">{{ __('general.status_approve') }}</label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="{{ __('general.'.$request_withdraw->status) }}" aria-describedby="emailHelp" disabled>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    @if($request_withdraw->status == 'requested')
      <form method="post" action="{{ url('/request-withdraw/change-approve') }}">
        @csrf
        <input type="hidden" name="id" value="{{ $request_withdraw->id }}"/>
        <input type="hidden" name="status" value="accepted"/>
        <button class="btn btn-primary">{{ __('general.set_approve') }}</button>
      </form>

      <form method="post" class="ml-3" action="{{ url('/request-withdraw/change-approve') }}">
        @csrf
        <input type="hidden" name="id" value="{{ $request_withdraw->id }}"/>
        <input type="hidden" name="status" value="declined"/>
        <button class="btn btn-primary">{{ __('general.set_decline') }}</button>
      </form>
    @endif
  </div>
</div>