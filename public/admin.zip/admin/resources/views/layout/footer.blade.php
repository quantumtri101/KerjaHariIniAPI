<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>{!! __('general.footer') !!}</span>
    </div>
  </div>
</footer>
