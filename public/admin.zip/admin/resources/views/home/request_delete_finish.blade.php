@extends('layout.base_empty')

@section('content')
<div>
	<h5>{{ __('general.request_account_deleted_finish') }}</h5>
	<p>{{ __('general.request_account_deleted_finish_description') }}</p>
</div>
@endsection
