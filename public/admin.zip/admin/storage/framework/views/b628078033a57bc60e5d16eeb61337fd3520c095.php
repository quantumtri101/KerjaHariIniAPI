

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.salary_verification'),
    ],
    "title" => __('salary_verification.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('salary_verification.title')); ?></h5>

    
  </div>

  <div class="mt-3">
    <ul class="nav nav-pills" id="detailTab" role="tablist">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link border-0" id="<?php echo e($tab["id"]); ?>-tab" data-toggle="tab" data-target="#<?php echo e($tab["id"]); ?>" type="button" role="tab" onclick="on_tab_clicked('<?php echo e($tab["id"]); ?>', '<?php echo e($tab["url"]); ?>')" aria-controls="<?php echo e($tab["id"]); ?>" aria-selected="true"><?php echo e(__('general.'.$tab["id"])); ?></button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="mt-3 d-none" id="filter_container">
      <?php echo $__env->make('layout.reservation_filter',[
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <!-- Tab panes -->
    <div class="tab-content mt-3" id="pills-detailTabContent">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane" id="<?php echo e($tab["id"]); ?>" role="tabpanel" aria-labelledby="<?php echo e($tab["id"]); ?>-tab">
        <div class="card">
          <div class="card-body">
            <?php echo $__env->make($tab["component"], [
              "url" => $tab["url"],
              "id" => $tab["id"],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var arr_datatable = []
  function init_datatable(id, url){
    if(arr_datatable[id] != null)
      arr_datatable[id].destroy()

    arr_datatable[id] = $('#datatable' + id).DataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: 'Bfrtip',
      buttons: [
        // {
        //   className: 'btn btn-primary',   
        //   text : "<?php echo e(__('general.add')); ?>",
        //   action: function ( e, dt, node, config ) {
        //     save_current_page("<?php echo e(__('salary_verification.title')); ?>")
        //     location.href = "<?php echo e(url('/check-log/action')); ?>"
        //   },
        //   init: function(api, node, config) {
        //     $(node).removeClass('dt-button')
        //   },
        // },
      ],
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : url,
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "event_name", name: "event.name"},
        {"data" : "jobs_name", name: "jobs1.name"},
        {"data" : "working_date_format", name: "jobs_shift.start_date"},
        {"data" : "total_check_in_format", name: "total_check_in"},
        {"data" : "total_check_out_format", name: "total_check_out"},
        {"data" : "action", "orderable" : false},
      ],
      "columnDefs" : [
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var str = ""
            str += '<div style="width: auto">'
              str += `<a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('salary_verification.title')); ?>')" href="<?php echo e(url('/salary/detail')); ?>?id=${row.id}"><?php echo e(__('general.detail')); ?></a>`
            str += '</div>'
            return str
          },
        },
      ]
    })
  }

  function on_tab_clicked(id, url){
    localStorage.setItem('menu', id)
    localStorage.setItem('url', url)
    this.init_datatable(id, url)
  }
  
  $(document).ready(async() => {
    var menu = await get_menu_detail("list_not_requested")
    var url = await localStorage.getItem('url')
      
    localStorage.setItem('menu', menu)
    this.init_datatable(menu, url != null ? url : '<?php echo e($arr_tab[0]["url"]); ?>')
      
    $('#' + menu + '-tab').addClass('active')
    $('#' + menu).addClass('show active')
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/salary/index.blade.php ENDPATH**/ ?>