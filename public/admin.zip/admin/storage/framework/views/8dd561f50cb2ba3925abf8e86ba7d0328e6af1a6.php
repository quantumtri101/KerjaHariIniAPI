

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.customer_oncall'),
      __('customer_oncall.detail'),
    ],
    "title" => __('customer_oncall.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => __('customer_oncall.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(!empty($jobs_application)): ?>
    <div class="card mt-3">
      <div class="card-body">
        <h5><?php echo e(__('general.application')); ?></h5>
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.application')); ?></label>
          <textarea class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled><?php echo e($jobs_application->content); ?></textarea>
        </div>

        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.status')); ?></label>
          <div>
            <span class=" pd-y-3 pd-x-10 tx-white tx-11 tx-roboto" style="background-color: #<?php echo e($jobs_application->status_bg_color); ?>"><?php echo e($jobs_application->status == "wait" && $jobs_application->is_approve_worker == 0 ? __('general.wait_customer') : $jobs_application->status); ?></span>
          </div>
        </div>

        <?php if($jobs_application->is_approve_corp == 0): ?>
          <div class="row">
            <?php if($jobs_application->status == 'wait' || $jobs_application->status == 'interview'): ?>
              <div class="col-12 col-lg-4">
                <form method="post" action="<?php echo e(url('/jobs/application/change-status')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($jobs_application->id); ?>"/>
                  <input type="hidden" name="status" value="declined"/>
                  <button class="btn btn-primary w-100"><?php echo e(__('general.decline')); ?></button>
                </form>
              </div>
            <?php endif; ?>
            <?php if($jobs_application->status == 'wait' && count($jobs_application->jobs->interview) > 0): ?>
              <div class="col-12 col-lg-4">
                <form method="post" action="<?php echo e(url('/jobs/application/change-status')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($jobs_application->id); ?>"/>
                  <input type="hidden" name="status" value="interview"/>
                  <button class="btn btn-primary w-100"><?php echo e(__('general.do_interview')); ?></button>
                </form>
              </div>
            <?php elseif($jobs_application->status == 'interview' && count($jobs_application->jobs->briefing) > 0): ?>
              <div class="col-12 col-lg-4">
                <form method="post" action="<?php echo e(url('/jobs/application/change-status')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($jobs_application->id); ?>"/>
                  <input type="hidden" name="status" value="accepted"/>
                  <button class="btn btn-primary w-100"><?php echo e(__('general.do_briefing')); ?></button>
                </form>
              </div>
            <?php endif; ?>
            <?php if($jobs_application->status == 'wait' || $jobs_application->status == 'interview'): ?>
              <div class="col-12 col-lg-4">
                <form method="post" action="<?php echo e(url('/jobs/application/change-status')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($jobs_application->id); ?>"/>
                  <input type="hidden" name="status" value="accepted"/>
                  <button class="btn btn-primary w-100"><?php echo e(__('general.accept')); ?></button>
                </form>
              </div>
            <?php endif; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  <?php endif; ?>

  <div class="mt-3">
    <ul class="nav nav-pills" id="detailTab" role="tablist">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link border-0" id="<?php echo e($tab["id"]); ?>-tab" data-toggle="tab" data-target="#<?php echo e($tab["id"]); ?>" type="button" role="tab" onclick="on_tab_clicked('<?php echo e($tab["id"]); ?>')" aria-controls="<?php echo e($tab["id"]); ?>" aria-selected="true"><?php echo e(__('general.'.$tab["id"])); ?></button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    
    <!-- Tab panes -->
    <div class="tab-content mt-3" id="pills-detailTabContent">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane" id="<?php echo e($tab["id"]); ?>" role="tabpanel" aria-labelledby="<?php echo e($tab["id"]); ?>-tab">
        <div class="card">
          <div class="card-body">
            <?php echo $__env->make($tab["component"], [
              "customer_oncall" => $customer_oncall,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      function on_tab_clicked(id){
        localStorage.setItem('menu', id)
      }
      
      $(document).ready(async() => {
        var menu = await localStorage.getItem('menu')
        if(menu === "" || menu == null)
          menu = "general_info"
          
        localStorage.setItem('menu', menu)
          
        $('#' + menu + '-tab').addClass('active')
        $('#' + menu).addClass('show active')

        
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/detail.blade.php ENDPATH**/ ?>