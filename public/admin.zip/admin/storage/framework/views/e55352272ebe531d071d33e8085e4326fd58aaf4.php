

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.jobs'),
      __($lang_file.'.detail'),
      __($lang_file.'.edit'),
    ] : [
      __('general.jobs'),
      __($lang_file.'.add'),
    ],
    "title" => Request::has('id') ? __($lang_file.'.edit') : __($lang_file.'.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __($lang_file.'.edit') : __($lang_file.'.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" id="jobsForm" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/jobs/edit' : '/jobs')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>
        <input type="hidden" name="type" id="jobs_type"/>
        <input type="hidden" name="publish_start_date" id="publish_start_date"/>
        <input type="hidden" name="publish_end_date" id="publish_end_date"/>

        <div id="wizard1">
          <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3><?php echo e(__('general.'.$tab["id"])); ?></h3>
            <section>
              <?php echo $__env->make($tab["component"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        

        
      </form>
    </div>
  </div>

  <?php echo $__env->make('layout.modal.jobs_submit_ask', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layout.modal.publish_date_add_jobs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php $__env->startPush('script'); ?>
    <script>
      var selected_event = {}
      var selected_menu = 0
      var from_system = false
      function on_tab_clicked(id){
        localStorage.setItem('menu', id)
      }
      
      $(document).ready(async() => {
        var menu = await get_menu_detail()
        localStorage.setItem('menu', menu)

        $('#' + menu + '-tab').addClass('active')
        $('#' + menu).addClass('show active')

        var wizard = $('#wizard1').steps({
          headerTag: 'h3',
          bodyTag: 'section',
          // autoFocus: true,
          titleTemplate: '<span class="number">#index#</span> <span class="title">#title#</span>',
          onStepChanged: function (event, currentIndex, priorIndex) {
            if(from_system){
              from_system = false
              return
            }
            var message = ""
            
            if(priorIndex == 0 && check_general() != '')
              message = check_general()
            else if(priorIndex == 1 && check_jobs() != '')
              message = check_jobs()
            else if(priorIndex == 2 && check_criteria() != '')
              message = check_criteria()
            else if(priorIndex == 3 && check_qualification() != '')
              message = check_qualification()
            else if(priorIndex == 4 && check_brief_interview() != '')
              message = check_brief_interview()
            else{
              if(priorIndex == 0 && currentIndex == 1){
                <?php $__currentLoopData = $arr_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  if($('#event_id').val() == '<?php echo e($event->id); ?>')
                    selected_event = {
                      id: '<?php echo e($event->id); ?>',
                      name: '<?php echo e($event->name); ?>',
                      start_date: moment('<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
                      end_date: moment('<?php echo e($event->end_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
                init_date()
              }
              if(currentIndex == 0)
                $('#btn-cancel').removeClass('d-none')
              else
                $('#btn-cancel').addClass('d-none')
            }
            
            if(message != ''){
              notify_user(message)
              window.setTimeout(() => {
                from_system = true
                $("#wizard1-t-"+priorIndex).get(0).click();
              }, 100)
            }
          },
          onFinished: function (event, currentIndex) {
            var menu1 = -1
            var message = ""
            var message_general = check_general()
            var message_jobs = check_jobs()
            var message_criteria = check_criteria()
            var message_qualification = check_qualification()
            var message_brief_interview = check_brief_interview()

            if(message_general != ""){
              message = message_general
              menu1 = 0
            }
            else if(message_jobs != ""){
              message = message_jobs
              menu1 = 1
            }
            else if(message_criteria != ""){
              message = message_criteria
              menu1 = 2
            }
            else if(message_qualification != ""){
              message = message_qualification
              menu1 = 3
            }
            else if(message_brief_interview != ""){
              message = message_brief_interview
              menu1 = 4
            }
            selected_menu = menu1

            if(message !== ""){
              $("#wizard1-t-"+menu1).get(0).click();
              // $('#' + menu1 + '-tab').tab('show')
              notify_user(message, event)
              return
            }

            <?php if(Request::has('id')): ?>
              back_page(false)
              $('#jobsForm').trigger('submit')
            <?php else: ?>
              if($('#radio-open').is(':checked')){
                shift_start_date = $('#radio-split-no').is(':checked') ? moment($('#startdatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment($('#starttimepicker1').val(), 'DD-MM-YYYY HH:mm')
                shift_end_date = $('#radio-split-no').is(':checked') ? moment($('#enddatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment($('#endtimepicker1').val(), 'DD-MM-YYYY HH:mm')
                $('#jobs_submit_ask_modal').modal('show')
              }
              else{
                back_page(false)
                $('#jobsForm').trigger('submit')
              }
            <?php endif; ?>
          }
        });
        var $input = $('<a class="btn btn-outline-secondary" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>');
        $input.prependTo($('.actions'));
        $('.actions').addClass('d-flex')
        $('ul[aria-label="Pagination"]').addClass('w-100 ml-3')

        <?php echo $__env->yieldPushContent('afterScript'); ?>
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/action.blade.php ENDPATH**/ ?>