<div>
  <div class="card">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">List Image</h5>
      <?php echo $__env->make('jobs.component.list_image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">List Qualification</h5>
      <?php echo $__env->make('jobs.component.list_qualification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">Criteria</h5>
      <?php echo $__env->make('jobs.component.criteria_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">Briefing</h5>
      <?php echo $__env->make('jobs.component.briefing_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">Interview</h5>
      <?php echo $__env->make('jobs.component.interview_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/job_description.blade.php ENDPATH**/ ?>