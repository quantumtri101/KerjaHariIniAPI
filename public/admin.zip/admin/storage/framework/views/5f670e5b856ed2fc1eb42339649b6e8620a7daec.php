<nav class="breadcrumb pd-0 mg-0 tx-12" id="custom_breadcrumb">
  <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == count($arr) - 1): ?>
      <span class="breadcrumb-item active"><?php echo e($data); ?></span>
    <?php else: ?>
      <a class="breadcrumb-item bc-click" href="#" index="<?php echo e(count($arr) - 1 - $key); ?>"><?php echo e($data); ?></a>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<?php $__env->startPush('script'); ?>
  <script>
    var arr_stack_title = []
    $(document).ready(() => {
      arr_stack_title = window.localStorage.getItem('arr_stack_title') != null ? JSON.parse(window.localStorage.getItem('arr_stack_title')) : []

      var str = ''
      for(let x in arr_stack_title){
        str += `<a class="breadcrumb-item bc-click" href="#" index="${arr_stack_title.length - x}">${arr_stack_title[x]}</a>`
      }
      str += `<span class="breadcrumb-item active"><?php echo e(!empty($title) ? $title : ''); ?></span>`
      $('#custom_breadcrumb').html(str)

      $('.bc-click').click(function() {
        var index = $(this).attr('index')
        for(let x = 0; x < index; x++){
          back_page(x == index - 1)
        }
      })
    })
  </script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/custom_breadcrumb.blade.php ENDPATH**/ ?>