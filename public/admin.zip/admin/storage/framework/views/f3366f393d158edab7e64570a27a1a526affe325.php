<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.calendar'),
    ],
    "title" => __('calendar.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('calendar.title')); ?></h5>

    
  </div>

  <div class="row">
    <div class="col-12">
      <div id="calendar"></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var jobs_datatable = null
  var calendar = null
  var arr_event = []
  var arr_jobs = []

  function reload_calendar(){
    if(calendar == null){
      var context = this
      calendar = new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'dayGridMonth',
        eventClick: (info) => {
          var selected_data = {}
          for(let event of arr_event){
            if(info.event._def.publicId == event.id){
              selected_data = event
              break
            }
          }
          if(selected_data.id == null){
            for(let jobs of arr_jobs){
              if(info.event._def.publicId == jobs.id){
                selected_data = jobs
                break
              }
            }
          }

          if(selected_data.type == 'event'){
            save_current_page('<?php echo e(__("event.detail")); ?>')
            location.href = '<?php echo e(url("/event/detail")); ?>?id=' + selected_data.id
          }
          else if(selected_data.type == 'jobs'){
            save_current_page('<?php echo e(__("jobs.detail")); ?>')
            location.href = '<?php echo e(url("/jobs/detail")); ?>?id=' + selected_data.id
          }
        },
      })

      <?php $__currentLoopData = $arr_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        arr_event.push({
          id: '<?php echo e($event->id); ?>',
          name: '<?php echo e($event->name); ?>',
          start_date: moment('<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
          end_date: moment('<?php echo e($event->end_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
          type: 'event',
        })

        <?php $__currentLoopData = $event->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!empty($jobs->start_shift) && !empty($jobs->end_shift)): ?>
            arr_jobs.push({
              id: '<?php echo e($jobs->id); ?>',
              name: '<?php echo e($jobs->name); ?>',
              start_date: moment('<?php echo e($jobs->start_shift->start_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
              end_date: moment('<?php echo e($jobs->end_shift->end_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD'),
              type: 'jobs',
            })
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      setTimeout(() => {
        calendar.render()

        <?php $__currentLoopData = $arr_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          calendar.addEvent({
            id: '<?php echo e($event->id); ?>',
            title: '<?php echo e($event->name); ?>',
            start: '<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>',
            end: '<?php echo e($event->end_date->addDays(1)->formatLocalized("%Y-%m-%d")); ?>',
            color: '#44A244',
            type: 'event',
          })
          

          <?php $__currentLoopData = $event->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($jobs->start_shift) && !empty($jobs->end_shift)): ?>
              calendar.addEvent({
                id: '<?php echo e($jobs->id); ?>',
                title: '<?php echo e($jobs->name); ?>',
                start: '<?php echo e($jobs->start_shift->start_date->formatLocalized("%Y-%m-%d")); ?>',
                end: '<?php echo e($jobs->end_shift->end_date->addDays(1)->formatLocalized("%Y-%m-%d")); ?>',
                color: '#FF0000',
                type: 'job',
              })
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          // console.log()
          // calendar.gotoDate(moment('<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD').toDate());
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      }, 100);
    }
  }

  $(document).ready(function () {
    reload_calendar()    
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/calendar/calendar.blade.php ENDPATH**/ ?>