

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.general_quiz'),
    ],
    "title" => __('general_quiz.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('general_quiz.title')); ?></h5>

    
  </div>

  <div class="mt-3">
    <table class="table" id="datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.total_option')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.action')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  $(document).ready(async function () {
    datatable = $('#datatable').dataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: 'Bfrtip',
      buttons: [
        {
          className: 'btn btn-primary',   
          text : "<?php echo e(__('general.add')); ?>",
          action: function ( e, dt, node, config ) {
            save_current_page("<?php echo e(__('general_quiz.title')); ?>")
            location.href = "<?php echo e(url('/general-quiz/multiple')); ?>"
          },
          init: function(api, node, config) {
            $(node).removeClass('dt-button')
          },
        },
      ],
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : "<?php echo e(url('api/general-quiz/question')); ?>",
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "name", name: "name"},
        {"data" : "total_option", name: "total_option"},
        {"data" : "action", "orderable" : false},
      ],
      "columnDefs" : [
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var str = ""
            str += '<div style="width: 150px">'
              str += `<a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('general_quiz.title')); ?>')" href="<?php echo e(url('/general-quiz/detail')); ?>?id=${row.id}")><?php echo e(__('general.detail')); ?></a>`
              if(row.allow_delete)
                str += `<a class="btn btn-danger ml-3" href="#!" onclick="alertDelete('<?php echo e(url('/general-quiz/delete')); ?>?id=${row.id}')")>Delete</a>`
            str += '</div>'
            return str
          },
        },
      ]
    })
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/general_quiz/index.blade.php ENDPATH**/ ?>