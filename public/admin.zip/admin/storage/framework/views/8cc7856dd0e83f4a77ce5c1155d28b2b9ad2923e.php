<div>
  <div class="row">
    <div class="col-6">
      <p class="m-0"><?php echo e(__('general.last_update')); ?>: <?php echo e($customer_oncall->resume[0]->updated_at->formatLocalized('%d/%m/%Y')); ?></p>
    </div>
    <div class="col-6 text-right">
      <a class="btn btn-primary" href="<?php echo e(url('/export/resume?id='.$customer_oncall->resume[0]->id)); ?>" target="_blank"><?php echo e(__('general.download_resume')); ?></a>
    </div>

    <div class="col-8 offset-md-2">
      <div class="mt-3 card">
        <div class="card-body">
          <div class="row bg-white">
            <div class="col-6">
              <div class="card">
                <div class="card-body">
                  <img src="<?php echo e(url('/image/user?file_name='.$customer_oncall->resume[0]->user->file_name)); ?>" style="width: 30rem; border-radius: 30rem;"/>
                  <p class="m-0"><?php echo e($customer_oncall->resume[0]->name); ?></p>
                  <p class="m-0"><?php echo e($customer_oncall->resume[0]->phone); ?></p>
                  <p class="m-0"><?php echo e(__('general.user_from', ["date" => $customer_oncall->resume[0]->created_at->formatLocalized('%d %B %Y')])); ?></p>
                </div>
              </div>

              <div class="mt-3">
                <div class="row">
                  <div class="col-12">
                    <p class="m-0"><?php echo e(__('general.personal_detail')); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.gender')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e(__('general.'.($customer_oncall->gender == 1 ? 'male' : 'female'))); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.birth_date')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e($customer_oncall->resume[0]->birth_date->formatLocalized('%d %B %Y')); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.address')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e($customer_oncall->resume[0]->address); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.status')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e(__('general.'.$customer_oncall->resume[0]->marital_status)); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.last_education')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e(!empty($customer_oncall->resume[0]->last_education) ? $customer_oncall->resume[0]->last_education : '-'); ?></p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.height')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e($customer_oncall->resume[0]->height); ?> cm</p>
                  </div>
                  <div class="col-6">
                    <p class="m-0"><?php echo e(__('general.weight')); ?></p>
                  </div>
                  <div class="col-6 text-right">
                    <p class="m-0"><?php echo e($customer_oncall->resume[0]->weight); ?> kg</p>
                  </div>
                </div>
              </div>

              <div class="mt-3">
                <div class="row">
                  <div class="col-12">
                    <p class="m-0"><?php echo e(__('general.skill')); ?></p>
                  </div>
                  <div class="col-12">
                    <?php $__currentLoopData = $customer_oncall->resume[0]->skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <p class="m-0"><?php echo e($key + 1); ?>. <?php echo e(!empty($skill->skill) ? $skill->skill->name : $skill->custom_skill); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-6">
              <p class="m-0"><?php echo e(__('general.resume')); ?></p>
              <div class="mt-3">
                <p class="m-0 mt-3"><?php echo e(__('general.work_experience')); ?></p>
                <?php $__currentLoopData = $customer_oncall->resume[0]->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="mt-1">
                    <p class="m-0"><?php echo e($experience->name); ?></p>
                    <p class="m-0"><?php echo e($experience->start_year); ?> - <?php echo e($experience->end_year); ?></p>
                    <div class="d-flex align-items-center">
                      <div class="d-flex align-items-center">
                        <i class="fa-solid fa-building"></i>
                        <p class="m-0 ml-1"><?php echo e($experience->corporation); ?></p>
                      </div>

                      <div class="d-flex align-items-center ml-3">
                        <i class="fa-solid fa-location-dot"></i>
                        <p class="m-0 ml-1"><?php echo e($experience->city->name); ?></p>
                      </div>
                    </div>
                    <p class="m-0"><?php echo e($experience->description); ?></p>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/resume_data.blade.php ENDPATH**/ ?>