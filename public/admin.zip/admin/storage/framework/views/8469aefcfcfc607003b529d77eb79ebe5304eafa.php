<div class="row">
  <div class="col-12 col-lg-8">
    <div class="row">
      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.id')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($company->id); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.city_name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(!empty($company->city) ? $company->city->name : '-'); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.category_name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(!empty($company->category) ? $company->category->name : '-'); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($company->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.phone')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($company->phone); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.address')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($company->address); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="form-group">
      <label for="exampleInputEmail1"><?php echo e(__('general.image')); ?></label>
      <div>
        <img src="<?php echo e(url('/image/company?file_name='.$company->file_name)); ?>" width="50%"/>
      </div>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    <a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('company.detail')); ?>')" href="<?php echo e(url('/master/company/action?id='.$company->id)); ?>"><?php echo e(__('general.edit')); ?></a>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/company/component/general_info.blade.php ENDPATH**/ ?>