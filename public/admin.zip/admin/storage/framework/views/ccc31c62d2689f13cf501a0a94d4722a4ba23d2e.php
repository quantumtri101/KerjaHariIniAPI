<div>
  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th><?php echo e(__('general.name')); ?></th>
        <th><?php echo e(__('general.action')); ?></th>
      </tr>
    </thead>
    <tbody id="table_body_skill">
      
    </tbody>
  </table>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    var arr_skill = []

    async function manage_arr_skill(){
      var str = ""
      if(arr_skill.length > 0){
        for(let x in arr_skill){
          str += `
            <tr>
              <td>${arr_skill[x].skill.name}</td>
              <td>
                <button class="btn btn-primary" type="button" onclick="on_edit_skill(${x})"><?php echo e(__("general.edit")); ?></button>
                <button class="btn btn-danger" type="button" onclick="on_delete_skill(${x})"><?php echo e(__("general.delete")); ?></button>
              </td>
            </tr>
          `
        }
      }
      else
        str += `
          <tr>
            <td colspan="5" class="text-center"><?php echo e(__('general.no_data')); ?></td>
          </tr>
        `

      $('#arr_skill').val(JSON.stringify(arr_skill))
      $('#table_body_skill').html(str)
    }

    $(document).ready(() => {
      
    })
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
<?php if(!empty($user) && count($user->resume) > 0): ?>
  <?php $__currentLoopData = $user->resume[0]->skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    arr_skill.push({
      id: '<?php echo e($skill->id); ?>',
      skill: {
        id: '<?php echo e($skill->skill->id); ?>',
        name: '<?php echo e($skill->skill->name); ?>',
      }
    })
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

manage_arr_skill()
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/action/skill/table.blade.php ENDPATH**/ ?>