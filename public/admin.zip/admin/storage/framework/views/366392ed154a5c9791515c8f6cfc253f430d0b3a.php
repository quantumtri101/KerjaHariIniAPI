<div>
  <div class="mt-3 table-responsive">
    <table class="table w-100" id="list_rating_datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">#</th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.jobs')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.user')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.rating')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.review')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  $(document).ready(function () {

    datatable = $('#list_rating_datatable').dataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : "<?php echo url('api/rating?staff_id='.$customer_oncall->id); ?>",
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[1, "desc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "id", "orderable" : false, },
        {"data" : "jobs_name", name: "jobs1.name"},
        {"data" : "user_name", name: "user.name"},
        {"data" : "rating", name: "rating"},
        {"data" : "review", name: "review"},
      ],
    })
  })
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/list_rating.blade.php ENDPATH**/ ?>