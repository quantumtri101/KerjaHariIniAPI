<div>
  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th><?php echo e(__('general.name')); ?></th>
        <th><?php echo e(__('general.working_year')); ?></th>
        <th><?php echo e(__('general.company')); ?></th>
        <th><?php echo e(__('general.location')); ?></th>
        <th><?php echo e(__('general.description')); ?></th>
        <th><?php echo e(__('general.action')); ?></th>
      </tr>
    </thead>
    <tbody id="table_body_experience">
      
    </tbody>
  </table>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    var arr_experience = []

    async function manage_arr_experience(){
      var str = ""
      if(arr_experience.length > 0){
        for(let x in arr_experience){
          str += `
            <tr>
              <td>${arr_experience[x].name}</td>
              <td>${arr_experience[x].start_year} - ${arr_experience[x].end_year}</td>
              <td>${arr_experience[x].company}</td>
              <td>${arr_experience[x].location}</td>
              <td>${arr_experience[x].description}</td>
              <td>
                <button class="btn btn-primary" type="button" onclick="on_edit_experience(${x})"><?php echo e(__("general.edit")); ?></button>
                <button class="btn btn-danger" type="button" onclick="on_delete_experience(${x})"><?php echo e(__("general.delete")); ?></button>
              </td>
            </tr>
          `
        }
      }
      else
        str += `
          <tr>
            <td colspan="5" class="text-center"><?php echo e(__('general.no_data')); ?></td>
          </tr>
        `

      $('#arr_experience').val(JSON.stringify(arr_experience))
      $('#table_body_experience').html(str)
    }

    $(document).ready(() => {
      
    })
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
<?php if(!empty($user) && count($user->resume) > 0): ?>
  <?php $__currentLoopData = $user->resume[0]->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    arr_experience.push({
      id: '<?php echo e($experience->id); ?>',
      name: '<?php echo e($experience->name); ?>',
      start_year: '<?php echo e($experience->start_year); ?>',
      end_year: '<?php echo e($experience->end_year); ?>',
      company: '<?php echo e($experience->corporation); ?>',
      location: '<?php echo e($experience->city->name); ?>',
      city: {
        id: '<?php echo e($experience->city->id); ?>',
      },
      description: '<?php echo e($experience->description); ?>',
    })
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

manage_arr_experience()
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/action/experience/table.blade.php ENDPATH**/ ?>