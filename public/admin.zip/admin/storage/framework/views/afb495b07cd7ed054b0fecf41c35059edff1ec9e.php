<div class="d-flex align-items-center justify-content-between">
  <?php if(empty($include_back_button) || (!empty($include_back_button) && $include_back_button)): ?>
    <div class="d-flex align-items-center">
      <button class="btn btn-primary" onclick="back_page()"><i class="fa-solid fa-arrow-left m-0"></i></button>
      <h5 class="mb-0 text-gray-800 font-weight-bold ml-3"><?php echo e($title); ?></h5>
    </div>
  <?php endif; ?>

  <div>
    <?php if(!empty($arr_additional_item)): ?>
      <?php $__currentLoopData = $arr_additional_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item["type"] == "to_other_page"): ?>
          <a href="<?php echo e($item["url"]); ?>" class="btn btn-primary"><?php echo e($item["text"]); ?></a>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/custom_navigation.blade.php ENDPATH**/ ?>