

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.check_log'),
    ],
    "title" => __('check_log.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('check_log.title')); ?></h5>

    
  </div>

  <div class="mt-3 table-responsive">
    <table class="table" id="datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.event_name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.job_name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.working_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.total_check_in')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.total_check_out')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.action')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(async() => {
      datatable = $('#datatable').dataTable({
        "processing" : true,
        "serverSide" : true,
        bLengthChange: false,
        responsive: true,
        dom: 'Bfrtip',
        buttons: [
          // {
          //   className: 'btn btn-primary',   
          //   text : "<?php echo e(__('general.add')); ?>",
          //   action: function ( e, dt, node, config ) {
          //     save_current_page("<?php echo e(__('check_log.title')); ?>")
          //     location.href = "<?php echo e(url('/check-log/action')); ?>"
          //   },
          //   init: function(api, node, config) {
          //     $(node).removeClass('dt-button')
          //   },
          // },
          // {
          //   className: 'btn btn-primary',   
          //   text : "<?php echo e(__('general.export')); ?>",
          //   action: function ( e, dt, node, config ) {
          //     location.href = "<?php echo e(url('/check-log/export')); ?>"
          //   },
          //   init: function(api, node, config) {
          //     $(node).removeClass('dt-button')
          //   },
          // },
        ],
        language: {
          searchPlaceholder: 'Search...',
          sSearch: '',
        },
        "ajax" : {
          url : `<?php echo e(url('api/jobs/shift')); ?>?is_approve=1&arr_type=["applicant_full"]&is_requested_check_log=0`,
          type : "GET",
          dataType : "json",
          headers : {
            "content-type": "application/json",
            "accept": "application/json",
            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
          },
        },
        "order" : [[2, "asc"]],
        // deferLoading: 2,
        "columns" : [
          {"data" : "event_name", name: "event.name"},
          {"data" : "jobs_name", name: "jobs1.name"},
          {"data" : "working_date_format", name: "jobs_shift.start_date"},
          {"data" : "total_check_in_format", name: "total_check_in"},
          {"data" : "total_check_out_format", name: "total_check_out"},
          {"data" : "action", "orderable" : false},
        ],
        "columnDefs" : [
          {
            targets: -1,
            data: null,
            sorting: false,
            render: function(data, type, row, meta) {
              var str = ""
              str += '<div style="width: 150px">'
                str += `
                  <a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('check_log.title')); ?>')" href="<?php echo e(url('/check-log/detail')); ?>?id=${row.id}"><?php echo e(__('general.detail')); ?></a>
                  <a class="btn btn-primary" target="_blank" href="<?php echo e(url('/jobs/print-qr')); ?>?id=${row.jobs.id}"><?php echo e(__('general.print_qr')); ?></a>
                `
              str += '</div>'
              return str
            },
          },
        ]
      })
    })
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/check_log/index_bck.blade.php ENDPATH**/ ?>