<div class="">
  <input type="hidden" id="arr_qualification" name="arr_qualification"/>
  <div class="row">
    <?php if((!empty($jobs) && $jobs->allow_edit) || empty($jobs)): ?>
      <div class="col-12 col-lg-4">
        <?php echo $__env->make('jobs.component.action.qualification.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    <?php endif; ?>
    <div class="col-12 <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? 'col-lg-8' : ''); ?> mt-3 mt-lg-0">
      <?php echo $__env->make('jobs.component.action.qualification.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    function check_qualification(){
      var message = ""
      if(arr_qualification.length == 0)
        message = "<?php echo e(__('general.qualification_empty')); ?>"
      return message
    }
  </script>
  <?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/action/qualification_info.blade.php ENDPATH**/ ?>