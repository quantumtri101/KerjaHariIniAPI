

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.sub_category'),
      __('sub_category.edit'),
    ] : [
      __('general.sub_category'),
      __('sub_category.add'),
    ],
    "title" => Request::has('id') ? __('sub_category.edit') : __('sub_category.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('sub_category.edit') : __('sub_category.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form method="post" class="mt-3" action="<?php echo e(url('/master/sub-category/multiple')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>

  <div class="card mt-3">
    <div class="card-body">
      <div class="form-group">
        <label><?php echo e(__('general.category')); ?></label>
        <select name="category_id" class="form-control">
          <?php $__currentLoopData = $arr_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <input type="hidden" id="arr_sub_category" name="arr_sub_category"/>
      <div class="row">
        <div class="col-12 col-lg-4">
          <?php echo $__env->make('master.sub_category.component.multiple.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 col-lg-8">
          <?php echo $__env->make('master.sub_category.component.multiple.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </div>

  <div class="form-group mt-3" >
    <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
    <button class="btn btn-primary" id="submit"><?php echo e(__('general.submit')); ?></button>
  </div>
</form>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(() => {
        $('#submit').click((e) => {
          if(arr_sub_category.length == 0){
            e.preventDefault()
            notify_user('<?php echo e(__("general.list_sub_category_empty")); ?>')
          }
          else
            back_page(false)
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/sub_category/multiple_add.blade.php ENDPATH**/ ?>