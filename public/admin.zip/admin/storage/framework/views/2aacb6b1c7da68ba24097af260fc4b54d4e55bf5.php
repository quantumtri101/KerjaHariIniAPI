<div class="br-logo">
  <a href=""><span><?php echo e(__('general.'.(Auth::user()->type->name == "RO" ? 'app_name_ro' : (Auth::user()->type->name == "staff" ? 'app_name_staff' : 'app_name_admin')))); ?></span></a>
</div>
  <div class="br-sideleft sideleft-scrollbar" style="background-color: #18355D;">
    <ul class="br-sideleft-menu my-3" id="accordionSidebar">

    <?php $__currentLoopData = $arr_sidebar['arr_sidebar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(!empty($sidebar["for_label"]) && $sidebar["for_label"]): ?>
        <label class="sidebar-label pd-x-10 mg-t-20 op-3"><?php echo e(__($sidebar["name"])); ?></label>
      <?php else: ?>
        <li class="br-menu-item">
          <?php if(!empty($sidebar['arr'])): ?>
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is($sidebar['url'].'*') ? 'active' : ''); ?>">
              <i class="menu-item-icon icon ion-ios-photos-outline tx-20"></i>
              <span class="menu-item-label"><?php echo e(__($sidebar['name'])); ?></span>
            </a>
            <ul class="br-menu-sub">
              <?php $__currentLoopData = $sidebar['arr']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="sub-item"><a href="<?php echo e($data['href']); ?>" @click="on_sidebar_clicked" class="sub-link <?php echo e(Request::is($data['url'].'*') ? 'active' : ''); ?>"><?php echo e(__($data['name'])); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          <?php else: ?>
            <a href="<?php echo e($sidebar['href']); ?>" class="br-menu-link <?php echo e(Request::is($sidebar['url'].'*') ? 'active' : ''); ?>" @click="on_sidebar_clicked">
              <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
              <span class="menu-item-label"><?php echo e(__($sidebar['name'])); ?></span>
            </a>
          <?php endif; ?>
        </li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>

  <!-- Sidebar Toggler (Sidebar) -->
  

</div>

<?php $__env->startPush('script'); ?>
  <script>
    var sidebar = new Vue({
      el: '#accordionSidebar',
      data: {
        arr_sidebar: []
      },
      created(){
        this.arr_sidebar = JSON.parse(('<?php echo e($arr_sidebar['json_arr_sidebar']); ?>').replace(/&quot;/g,'"'))
      },
      methods:{
        on_sidebar_clicked(){
          reset_page_stack()
        }
      }
    })
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/sidebar1.blade.php ENDPATH**/ ?>