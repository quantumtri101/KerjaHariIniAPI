

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.skill'),
      __('skill.edit'),
    ] : [
      __('general.skill'),
      __('skill.add'),
    ],
    "title" => Request::has('id') ? __('skill.edit') : __('skill.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('skill.edit') : __('skill.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/master/skill/edit' : '/master/skill')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="form-group">
          <label><?php echo e(__('general.skill')); ?></label>
          <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($skill) ? $skill->name : ''); ?>"/>
        </div>

        <div class="form-group" >
          <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
          <button class="btn btn-primary" id="submit"><?php echo e(__('general.submit')); ?></button>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(() => {
        $('#submit').click((e) => {
          
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/skill/action.blade.php ENDPATH**/ ?>