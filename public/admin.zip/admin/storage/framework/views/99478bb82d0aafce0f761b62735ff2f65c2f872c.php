<div>
  <?php if($allow_approve_salary): ?>
  <div id="approve_additional_salary_column">
    <form method="POST" class="d-inline-block" action="<?php echo e(url('/jobs/shift/approve/additional-salary')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($jobs_shift->id); ?>"/>
      <input type="hidden" name="approve_additional_salary_type" value="per_staff"/>
      <button class="btn btn-primary" <?php echo e($jobs_shift->approve_additional_salary_type != "none" ? 'disabled' : ''); ?>><?php echo e(__('general.approve_per_staff')); ?></button>
    </form>
    <form method="POST" class="d-inline-block" action="<?php echo e(url('/jobs/shift/approve/additional-salary')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo e($jobs_shift->id); ?>"/>
      <input type="hidden" name="approve_additional_salary_type" value="all"/>
      <button class="btn btn-primary" <?php echo e($jobs_shift->approve_additional_salary_type != "none" ? 'disabled' : ''); ?>><?php echo e(__('general.approve_all')); ?></button>
    </form>
  </div>
  <?php elseif(Auth::user()->type->name == "RO"): ?>
  <div>
    <button class="btn btn-primary" onclick='approvedSalaryAdditionalAction()'>Add Overtime Salary</button>
  </div>
  <?php endif; ?>
  <div class="mt-3 table-responsive">
    <table class="table w-100" id="list_additional_salary_datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.gender')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.id_no')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.overtime_salary')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.type')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.decline_reason')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_approve')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.'.($allow_approve_salary ? 'approval' : 'action'))); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<?php echo $__env->make('layout.modal.edit_salary_additional_verification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.decline_salary_additional_verification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var jobs_datatable = null

  function approvedSalaryAdditionalAction(){
    $('#salary_additional_jobs_shift_id').val('<?php echo e($jobs_shift->id); ?>')
    $('#edit_salary_additional_verification').modal('show')
  }

  function declinedSalaryAdditionalAction(data){
    $('#salary_additional_decline_user_id').val(data.user.id)
    $('#salary_additional_decline_jobs_shift_id').val('<?php echo e($jobs_shift->id); ?>')
    $('#salary_additional_decline_modal').modal('show')
  }

  function downloadAdditionalSalaryDocument(data){
    for(let x in data.additional_salary_document){
      setTimeout(() => {
        window.open("<?php echo e(url('/additional-salary/document/download')); ?>?id=" + data.additional_salary_document[x].id, "_blank")
      }, 100 * x);
    }
  }

  $(document).ready(function () {
    jobs_datatable = $('#list_additional_salary_datatable').DataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: 'Bfrtip',
      buttons: [
        // {
        //   className: 'btn btn-primary',   
        //   text : "<?php echo e(__('general.add')); ?>",
        //   action: function ( e, dt, node, config ) {
        //     save_current_page("<?php echo e(__('check_log.title')); ?>")
        //     location.href = "<?php echo e(url('/check-log/action')); ?>"
        //   },
        //   init: function(api, node, config) {
        //     $(node).removeClass('dt-button')
        //   },
        // },
      ],
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : `<?php echo e(url('api/jobs/application')); ?>?arr_is_approve_additional_salary=["requested","approved","declined"]&jobs_id=<?php echo e($jobs_shift->jobs->id); ?>`,
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "drawCallback": function (settings) { 
        // Here the response
        var response = settings.json;
        if(response.recordsTotal == 0)
          $('#approve_additional_salary_column').addClass('d-none')
        else
          $('#approve_additional_salary_column').removeClass('d-none')
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "user_name", name: "user.name"},
        {"data" : "gender_format", name: "resume.gender"},
        {"data" : "id_no", name: "resume.id_no"},
        {"data" : "additional_salary_format", name: "additional_salary_format"},
        {"data" : "type_name_format", name: "type.name"},
        {"data" : "decline_reason_additional_salary", name: "resume.decline_reason_additional_salary"},
        {"data" : "status_additional_salary_approve_format", name: "status_additional_salary_approve_format"},
        {"data" : "action", "orderable" : false},
      ],
      "columnDefs" : [
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var json = JSON.stringify(row)

            var status = ""
            if(row.is_approve_additional_salary == 'approved')
              status = "Approved"
            else if(row.is_approve_additional_salary == 'declined')
              status = "Declined"
            else if(row.is_approve_additional_salary == 'not_yet_approved')
              status = "Not yet Approved"
            else if(row.is_approve_additional_salary == 'requested')
              status = "Requested"
            
            var str = ""
            str += '<div style="width: auto">'
              <?php if($allow_approve_salary): ?>
                <?php if($jobs_shift->approve_additional_salary_type != "none"): ?>
                  if(row.is_approve_additional_salary == 'requested')
                    str += `
                      <form method="POST" action="<?php echo e(url('/salary/approve/additional-salary')); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="jobs_shift_id" value="<?php echo e($jobs_shift->id); ?>"/>
                        <input type="hidden" name="user_id" value="${row.user_id}"/>
                        <input type="hidden" name="is_approve_additional_salary" value="approved"/>
                        <button class="btn btn-primary" >Accept</button>
                      </form>
                      <button class="btn btn-danger" onclick='declinedSalaryAdditionalAction(${json})'>Decline</button>
                    `
                <?php endif; ?>
              <?php endif; ?>

              if(row.additional_salary_document.length > 0)
                str += `<button class="btn btn-primary mr-1" onclick='downloadAdditionalSalaryDocument(${json})'><?php echo e(__('general.download_all_file')); ?></button>`
            str += '</div>'
            return str
          },
        },
      ]
    })
  })
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/salary/component/list_additional_salary.blade.php ENDPATH**/ ?>