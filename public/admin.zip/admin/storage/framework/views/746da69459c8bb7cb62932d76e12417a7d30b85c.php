<div class="row">
  <div class="col-12">
    <div class="row">
      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.id')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($general_quiz_question->id); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.status_publish')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(__('general.'.($general_quiz_question->is_publish == 1 ? 'publish' : 'not_publish'))); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.question')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($general_quiz_question->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    <a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('general_quiz.detail')); ?>')" href="<?php echo e(url('/general-quiz/action?id='.$general_quiz_question->id)); ?>"><?php echo e(__('general.edit')); ?></a>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/general_quiz/component/general_info.blade.php ENDPATH**/ ?>