

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.event'),
      __('event.edit'),
    ] : [
      __('general.event'),
      __('event.add'),
    ],
    "title" => Request::has('id') ? __('event.edit') : __('event.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('event.edit') : __('event.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/event/edit' : '/event')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="form-group">
          <label><?php echo e(__('general.company')); ?></label>
          <select required name="company_id" class="form-control"  <?php echo e(Auth::user()->type->name == "RO" || Auth::user()->type->name == "staff" ? 'disabled' : ''); ?>>
            <?php $__currentLoopData = $arr_company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($company->id); ?>" <?php echo e((Auth::user()->type->name != "RO" && Auth::user()->type->name != "staff" && !empty($event) && $event->company->id == $company->id) || ((Auth::user()->type->name == "RO" || Auth::user()->type->name == "staff") && Auth::user()->company->id == $company->id) ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.name')); ?></label>
          <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($event) ? $event->name : ''); ?>"/>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.start_date')); ?></label>
          <div id="startdatetimepickererror">
            <label ><?php echo e(__('general.datepicker_error')); ?></label>
          </div>
          <input type="text" name="start_date" id="startdatetimepicker" class="form-control" data-toggle="datetimepicker"/>
        </div>
      
        <div class="form-group">
          <label><?php echo e(__('general.end_date')); ?></label>
          <div id="enddatetimepickererror">
            <label ><?php echo e(__('general.datepicker_error')); ?></label>
          </div>
          <input type="text" name="end_date" id="enddatetimepicker" class="form-control" data-toggle="datetimepicker" />
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.image')); ?></label>
          <?php echo $__env->make('layout.upload_multiple_photo', [
            "column" => "file_name",
            "form_name" => "image[]",
            "data" => $event,
            "id" => "event_image",
            "url_image" => "/image/event",
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="form-group" >
          <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
          <button class="btn btn-primary" id="submit"><?php echo e(__('general.submit')); ?></button>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      var startDateFirstTime = true
      var endDateFirstTime = true
      var startDateFirstTime1 = true
      var endDateFirstTime1 = true

      function init_start_date(){
        if(!startDateFirstTime){
          $('#startdatetimepicker').datetimepicker('destroy')

        }
        startDateFirstTime = false
        $('#startdatetimepickererror').addClass('d-none')
        $('#startdatetimepicker').removeClass('d-none')
        var start_date = '<?php echo e(!empty($event) ? $event->start_date->formatLocalized('%d-%m-%Y %H:%M') : ''); ?>'
        
        try{
          $('#startdatetimepicker').datetimepicker({
            format: 'DD-MM-YYYY HH:mm',
            useCurrent: false,
            defaultDate: $('#startdatetimepicker').val() !== "" ? moment($('#startdatetimepicker').val(), 'DD-MM-YYYY HH:mm') : (start_date != '' ? moment(start_date, 'DD-MM-YYYY HH:mm') : moment()),
            minDate: moment(),
            maxDate: !startDateFirstTime1 && $('#enddatetimepicker').val() !== "" ? moment($('#enddatetimepicker').val(), 'DD-MM-YYYY HH:mm') : false,
            icons: {
              time: 'fa-solid fa-clock',
              date: 'fa-solid fa-calendar',
            },
          })
        } catch(e){
          $('#startdatetimepickererror').removeClass('d-none')
          $('#startdatetimepicker').addClass('d-none')
        }

        $('#startdatetimepicker').on("show.datetimepicker", ({date, oldDate}) => {
          $('#enddatetimepicker').datetimepicker('hide')
        })

        $('#startdatetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
          if(oldDate != null){
            if(startDateFirstTime1)
              $('#enddatetimepicker').val(moment(date).add(1, 'd').format('DD-MM-YYYY HH:mm'))
            startDateFirstTime1 = false
            endDateFirstTime1 = false
            $('#startdatetimepicker').datetimepicker('hide')
            
            init_start_date()
            init_end_date()
          }
        })
      }

      function init_end_date(){
        if(!endDateFirstTime){
          $('#enddatetimepicker').datetimepicker('destroy')
        }
        endDateFirstTime = false
        $('#enddatetimepickererror').addClass('d-none')
        $('#enddatetimepicker').removeClass('d-none')
        var end_date = '<?php echo e(!empty($event) ? $event->end_date->formatLocalized('%d-%m-%Y %H:%M') : ''); ?>'
        
        try{
          $('#enddatetimepicker').datetimepicker({
            format: 'DD-MM-YYYY HH:mm',
            useCurrent: false,
            defaultDate: $('#enddatetimepicker').val() !== "" ? moment($('#enddatetimepicker').val(), 'DD-MM-YYYY HH:mm') : (end_date != "" ? moment(end_date, 'DD-MM-YYYY HH:mm') : moment().add(1, 'd')),
            minDate: $('#startdatetimepicker').val() !== "" ? moment($('#startdatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment().add(1, 'd'),
            icons: {
              time: 'fa-solid fa-clock',
              date: 'fa-solid fa-calendar',
            },
          })
        } catch(e){
          console.log(e)
          $('#enddatetimepickererror').removeClass('d-none')
          $('#enddatetimepicker').addClass('d-none')
        }

        $('#enddatetimepicker').on("show.datetimepicker", ({date, oldDate}) => {
          $('#startdatetimepicker').datetimepicker('hide')
        })

        $('#enddatetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
          if(oldDate != null){
            if(startDateFirstTime1)
              $('#startdatetimepicker').val(moment(date).subtract(1, 'd').format('DD-MM-YYYY HH:mm'))
            startDateFirstTime1 = false
            endDateFirstTime1 = false
            $('#enddatetimepicker').datetimepicker('hide')

            init_start_date()
            init_end_date()
          }
        })
      }

      $(document).ready(() => {
        <?php if(!empty($event)): ?>
          <?php $__currentLoopData = $event->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            arr_url_image.push('<?php echo e(url("/image/event?file_name=".$image->file_name)); ?>')
            arr_file_name.push('<?php echo e($image->file_name); ?>')
            arr_id.push('<?php echo e($image->id); ?>')
            arr_image.push(null)
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          on_change_multiple_imageevent_image()
        <?php endif; ?>
        init_start_date()
        init_end_date()

        $('#phone').keyup(() => {
          $('#phone').val(phone_validation($('#phone').val()))
        })
        $('#submit').click((e) => {
          
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/event/action.blade.php ENDPATH**/ ?>