

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.company'),
      __('company.edit'),
    ] : [
      __('general.company'),
      __('company.add'),
    ],
    "title" => Request::has('id') ? __('company.edit') : __('company.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('company.edit') : __('company.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/master/company/edit' : '/master/company')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="form-group">
          <label><?php echo e(__('general.category')); ?></label>
          <select name="category_id" required class="form-control">
            <?php $__currentLoopData = $arr_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>" <?php echo e(!empty($company) && !empty($compant->category) && $company->category->id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.province')); ?></label>
          <select name="province_id" id="province_id" required class="form-control">
            <option value=""><?php echo e(__('general.choose_province')); ?></option>
            <?php $__currentLoopData = $arr_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($province->id); ?>" <?php echo e(!empty($company) && !empty($company->city) && $company->city->province->id == $province->id ? 'selected' : ''); ?>><?php echo e($province->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.city')); ?></label>
          <select name="city_id" id="city_id" required class="form-control">
            <option value=""><?php echo e(__('general.choose_city')); ?></option>
            <?php $__currentLoopData = $arr_city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($city->id); ?>" <?php echo e(!empty($company) && !empty($company->city) && $company->city->id == $city->id ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.name')); ?></label>
          <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($company) ? $company->name : ''); ?>"/>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.phone')); ?></label>
          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><?php echo e(__('general.code_area')); ?></span>
            </div>
            <input type="text" required name="phone" id="phone" class="form-control" value="<?php echo e(!empty($company) ? substr($company->phone, 3) : ''); ?>"/>
          </div>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.address')); ?></label>
          <textarea required name="address" class="form-control"><?php echo e(!empty($company) ? $company->address : ''); ?></textarea>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.image')); ?></label>
          <?php echo $__env->make('layout.upload_photo', [
            "column" => "file_name",
            "form_name" => "image",
            "data" => $company,
            "id" => "image",
            "url_image" => "/image/company",
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="form-group" >
          <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
          <button class="btn btn-primary" id="submit" onclick=""><?php echo e(__('general.submit')); ?></button>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      async function get_city(){
        var response = await request('<?php echo e(url("/api/city/all")); ?>?is_publish=1&city_id=' + $('#province_id').val())
        if(response != null){
          if(response.status === "success"){
            var str = `
              <option value=""><?php echo e(__('general.choose_city')); ?></option>
            `
            for(let city of response.data)
              str += `<option value="${city.id}">${city.name}</option>`
            // console.log(response.data)
            $('#city_id').html(str)
          }
        }
      }
      
      $(document).ready(() => {
        var type = '<?php echo e(!empty($company) ? 'edit' : 'add'); ?>'
        $('#phone').keyup(() => {
          $('#phone').val(phone_validation($('#phone').val()))
        })
        $('#province_id').change(() => {
          get_city()
        })
        $('#submit').click((e) => {
          if(type == 'edit')
            back_page(false)
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/company/action.blade.php ENDPATH**/ ?>