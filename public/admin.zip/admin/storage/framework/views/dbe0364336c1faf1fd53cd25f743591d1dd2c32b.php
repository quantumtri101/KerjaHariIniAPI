

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.customer_regular'),
      __('customer_regular.detail'),
      __('customer_regular.edit'),
    ] : [
      __('general.customer_regular'),
      __('customer_regular.add'),
    ],
    "title" => Request::has('id') ? __('customer_regular.edit') : __('customer_regular.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('customer_regular.edit') : __('customer_regular.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/user/customer/regular/edit' : '/user/customer/regular')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="row">
          <div class="col-12 col-lg-4">
            <div class="mt-3">
              <label><?php echo e(__('general.image')); ?></label>
              <?php echo $__env->make('layout.upload_photo', [
                'id' => 'image',
                'data' => $user,
                'form_name' => 'image',
                'url_image' => '/image/user',
              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="mt-3">
              <label><?php echo e(__('general.covid_vaccine')); ?></label>
              <?php echo $__env->make('layout.upload_photo', [
                'id' => 'vaccine_covid',
                'data' => $user,
                'form_name' => 'vaccine_covid_image',
                'column' => 'vaccine_covid_file_name',
                'url_image' => '/image/user/vaccine',
              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="mt-3">
              <label><?php echo e(__('general.cv')); ?></label>
              <?php echo $__env->make('layout.upload_photo', [
                'id' => 'cv',
                'data' => $user,
                'form_name' => 'cv_image',
                'column' => 'cv_file_name',
                'url_image' => '/image/user/cv',
              ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>

          <div class="col-12 col-lg-8">
            <div class="form-group">
              <label><?php echo e(__('general.status_active')); ?></label>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="is_active" value="1" id="defaultCheckActive" required <?php echo e(!empty($user) && $user->is_active == '1' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="defaultCheckActive">
                  <?php echo e(__('general.active')); ?>

                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="is_active" value="0" id="defaultCheckInactive" required <?php echo e(!empty($user) && $user->is_active == '0' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="defaultCheckInactive">
                  <?php echo e(__('general.inactive')); ?>

                </label>
              </div>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.company')); ?></label>
              <select required name="company_id" <?php echo e(!empty(Auth::user()->company) ? 'disabled' : ''); ?> class="form-control">
                <option value=""><?php echo e(__('general.choose_company')); ?></option>
                <?php $__currentLoopData = $arr_company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->id); ?>" <?php echo e((!empty(Auth::user()->company) && Auth::user()->company->id == $company->id) || (empty(Auth::user()->company) && !empty($user) && !empty($user->company) && $user->company->id == $company->id) ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.name')); ?></label>
              <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($user) ? $user->name : ''); ?>"/>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.email')); ?></label>
              <input type="email" required name="email" class="form-control" value="<?php echo e(!empty($user) ? $user->email : ''); ?>"/>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.phone')); ?></label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="basic-addon1"><?php echo e(__('general.code_area')); ?></span>
                </div>
                <input type="text" required name="phone" id="phone" class="form-control" value="<?php echo e(!empty($user) ? $user->phone : ''); ?>"/>
              </div>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.gender')); ?></label>
              <select required name="gender" class="form-control">
                <option value="1" <?php echo e(!empty($user) && $user->gender == 1 ? 'selected' : ''); ?>><?php echo e(__('general.male')); ?></option>
                <option value="0" <?php echo e(!empty($user) && $user->gender == 0 ? 'selected' : ''); ?>><?php echo e(__('general.female')); ?></option>
              </select>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.contract_start_date')); ?></label>
              <input type="text" required name="contract_start_date" value="<?php echo e(!empty($user) ? $user->contract_start_date->formatLocalized('%d/%m/%Y') : ''); ?>" onkeydown="return false" id="contract_start_date" class="form-control datetimepicker-input" data-toggle="datetimepicker"/>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.contract_duration')); ?></label>
              <div class="input-group">
                <input type="text" required name="contract_duration" id="contract_duration" class="form-control" value="<?php echo e(!empty($user) ? number_format($user->contract_duration, 0, ',', '.') : ''); ?>"/>
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon1"><?php echo e(__('general.year')); ?></span>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.id_no')); ?></label>
              <input type="text" required name="id_no" id="id_no" class="form-control" value="<?php echo e(!empty($user) ? $user->id_no : ''); ?>"/>
            </div>
            

            
          </div>

          <div class="col-12 mt-3">
            <div class="form-group" >
              <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
              <button class="btn btn-primary" id="submit" onclick="back_page(false)"><?php echo e(__('general.submit')); ?></button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      // function init_birth_date(){
      //   $('#birth_date').datetimepicker('destroy')
      //   $('#birth_date').datetimepicker({
      //     format: 'DD/MM/YYYY',
      //     useCurrent: false,
      //     defaultDate: moment(birth_date, 'DD/MM/YYYY'),
      //     maxDate: moment().subtract(13, 'y'),
      //   })

      //   $('#birth_date').on("change.datetimepicker", ({date, oldDate}) => {
      //     if(oldDate != null){
      //       birth_date = $('#birth_date').val()
      //     }
      //   })
      // }

      $(document).ready(() => {
        $('#contract_start_date').datetimepicker({
          format: 'DD/MM/YYYY',
          useCurrent: false,
          defaultDate: $('#contract_start_date').val() != '' ? moment($('#contract_start_date').val(), 'DD/MM/YYYY') : moment(),
          // minDate: moment(),
        })

        $('#contract_duration').keyup(() => {
          $('#contract_duration').val(phone_validation($('#contract_duration').val(), 2))
        })

        $('#phone').keyup(() => {
          $('#phone').val(phone_validation($('#phone').val()))
        })

        $('#id_no').keyup(() => {
          $('#id_no').val(phone_validation($('#id_no').val(), 16))
        })

        // init_birth_date()
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/regular/action.blade.php ENDPATH**/ ?>