<div class="modal fade" id="rating_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('general.rating')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/rating')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="jobs_id" id="rating_jobs_id" value="<?php echo e($jobs->id); ?>" />

          <div class="form-group">
            <label for="exampleInputEmail1"><?php echo e(__('general.customer_oncall')); ?></label>
            <select name="staff_id" class="form-control">
              <option value=""><?php echo e(__('general.choose_customer')); ?></option>
              <?php $__currentLoopData = $arr_staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1"><?php echo e(__('general.rating')); ?></label>
            <input type="text" name="rating" id="rating" class="form-control">
          </div>

          <div class="form-group">
            <label for="exampleInputEmail1"><?php echo e(__('general.review')); ?></label>
            <textarea name="review" id="review" class="form-control"></textarea>
          </div>

          <div class="form-group">
            <button class="btn btn-primary">Submit</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(() => {
      $('#rating').keyup(() => {
        $('#rating').val(to_currency_format($('#rating').val()))
      })
    })
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/modal/rating.blade.php ENDPATH**/ ?>