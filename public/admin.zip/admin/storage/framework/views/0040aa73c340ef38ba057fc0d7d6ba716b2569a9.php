<?php $__env->startSection('content'); ?>
	<h5><?php echo e(__('general.request_account_deleted')); ?></h5>

	<form method="post" id="action" action="<?php echo e(url('/user/request-delete')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>

		<div class="row">
			<div class="col-12 mb-3">
				<div class="form-group">
					<label><?php echo e(__('general.email')); ?></label>
					<input type="text" required name="email" class="form-control"/>
				</div>
			</div>

			<div class="col-12 form-group">
				<button class="btn btn-primary"><?php echo e(__('general.submit')); ?></button>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base_empty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/home/request_delete.blade.php ENDPATH**/ ?>