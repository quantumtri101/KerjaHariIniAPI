<div>
  <div class="card">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">Detail Approval</h5>
      <?php echo $__env->make('jobs.component.list_approve', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php if(Auth::user()->type->name == "staff" && $jobs->status_approve == "not_yet_approved" && $jobs->before_allow_edit): ?>
        

        <a class="btn btn-primary" href="#!" onclick="showUploadDocumentModal('<?php echo e($jobs->id); ?>')">Approve</a>
        <a class="btn btn-danger ml-3" href="#!" onclick="showDeclineModal('<?php echo e($jobs->id); ?>')">Decline</a>

        <?php echo $__env->make('layout.modal.jobs_upload_document', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layout.modal.jobs_decline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">List Approve Check Log</h5>
      <?php echo $__env->make('jobs.component.list_approve_check_log', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <h5 class="mb-0 text-gray-800 font-weight-bold">List Approve Salary</h5>
      <?php echo $__env->make('jobs.component.list_approve_salary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/user_approval.blade.php ENDPATH**/ ?>