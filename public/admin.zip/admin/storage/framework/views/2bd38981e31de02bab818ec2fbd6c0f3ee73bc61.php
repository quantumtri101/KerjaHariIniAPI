

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [],
    "title" => __($lang_file.'.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => __($lang_file.'.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if($jobs->is_approve == -2): ?>
    <div class="alert alert-warning mt-3" role="alert">
      <?php echo e(__('general.jobs_client_decline_warning')); ?>

    </div>
  <?php endif; ?>

  <?php if($jobs->num_people_required > count($jobs->application)): ?>
  <div class="mt-3">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#scan_qr_ots_modal">
      <?php echo e(__('general.scan_qr_ots')); ?>

    </button>
  </div>
  <?php endif; ?>

  <div class="mt-3">
    <ul class="nav nav-pills" style="overflow-x: scroll; flex-wrap: nowrap;" id="detailTab" role="tablist">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link border-0" id="<?php echo e($tab["id"]); ?>-tab" data-toggle="tab" data-target="#<?php echo e($tab["id"]); ?>" type="button" role="tab" onclick="on_tab_clicked('<?php echo e($tab["id"]); ?>')" aria-controls="<?php echo e($tab["id"]); ?>" aria-selected="true"><?php echo e(__('general.'.$tab["id"])); ?></button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="mt-3 d-none" id="filter_container">
      <?php echo $__env->make('layout.reservation_filter',[
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <!-- Tab panes -->
    <div class="tab-content mt-3" id="pills-detailTabContent">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane" id="<?php echo e($tab["id"]); ?>" role="tabpanel" aria-labelledby="<?php echo e($tab["id"]); ?>-tab">
        <?php echo $__env->make($tab["component"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

  <?php echo $__env->make('jobs_application.component.modal.modal_applied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layout.modal.jobs_upload_pkhl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layout.modal.jobs_upload_pkwt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layout.modal.scanQR_OTS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layout.modal.jobs_decline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php $__env->startPush('script'); ?>
    <script>
      function on_tab_clicked(id){
        localStorage.setItem('menu', id)
      }

      function showDeclineModal(jobs_id){
        $('#jobs_decline_jobs_id').val(jobs_id)
        $('#jobs_decline_modal').modal('show')
      }

      function showUploadDocumentModal(jobs_id){
        $('#jobs_document_jobs_id').val(jobs_id)
        $('#extension_notice').html('<?php echo e(__("general.upload_document_extension")); ?>')
        $('#jobs_upload_document_modal').modal('show')
      }
      
      $(document).ready(async() => {
        var menu = await get_menu_detail()
          
        localStorage.setItem('menu', menu)
          
        $('#' + menu + '-tab').addClass('active')
        $('#' + menu).addClass('show active')
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/detail.blade.php ENDPATH**/ ?>