

<?php $__env->startSection('content'); ?>
  <div>
    <h3><?php echo e(__('general.change_password')); ?></h3>
    <form method="post" action="<?php echo e(url('/auth/change-password')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-12 mb-3">
          <div class="card">
            <div class="card-body">
              <div class="form-group">
                <label><?php echo e(__('general.current_password')); ?></label>
                <input type="password" class="form-control" required name="old_password"/>
              </div>
              <div class="form-group">
                <label><?php echo e(__('general.new_password')); ?></label>
                <input type="password" class="form-control" required id="new_password" name="new_password"/>
              </div>
              <div class="form-group">
                <label><?php echo e(__('general.confirm_password')); ?></label>
                <input type="password" class="form-control" required id="confirm_password" name="confirm_password"/>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12 mt-3">
          <button class="btn btn-primary" id="submit"><?php echo e(__('general.submit')); ?></button>
        </div>
      </div>
    </form>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(async() => {
        $('#submit').click((e) => {
          if($('#new_password').val() !== $('#confirm_password').val()){
            e.preventDefault()
            alert('<?php echo e(__("error_handler.confirm_password_not_same")); ?>')
          }
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/auth/change_password.blade.php ENDPATH**/ ?>