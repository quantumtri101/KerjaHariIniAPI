

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.bank'),
      __('bank.edit'),
    ] : [
      __('general.bank'),
      __('bank.add'),
    ],
    "title" => Request::has('id') ? __('bank.edit') : __('bank.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('bank.edit') : __('bank.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form method="post" class="mt-3" action="<?php echo e(url('/master/bank/multiple')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>

  <div class="card mt-3">
    <div class="card-body">
      <input type="hidden" id="arr_bank" name="arr_bank"/>
      <div class="row">
        <div class="col-12 col-lg-4">
          <?php echo $__env->make('master.bank.component.multiple.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 col-lg-8">
          <?php echo $__env->make('master.bank.component.multiple.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
  </div>

  <div class="form-group mt-3" >
    <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
    <button class="btn btn-primary" type="button" id="submit"><?php echo e(__('general.submit')); ?></button>
  </div>
</form>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(() => {
        $('#submit').click((e) => {
          if(arr_bank.length == 0){
            e.preventDefault()
            notify_user('<?php echo e(__("general.list_bank_empty")); ?>')
          }
          else
            back_page(false)
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/bank/multiple_add.blade.php ENDPATH**/ ?>