

<?php $__env->startSection('content'); ?>
  <h5 class="m-0"><?php echo e(__('privacy.edit')); ?></h5>

  <div class="my-3">
    <form method="post" action="<?php echo e(url('/master/privacy')); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <div class="card" id="privacy">
        <div class="card-body">
          <div class="form-group d-none">
            <label><?php echo e(__('general.title')); ?></label>
            <input type="text" name="title" class="form-control" value="<?php echo e(!empty($privacy) ? $privacy->title : ''); ?>"/>
          </div>

          <div class="form-group">
            <label><?php echo e(__('general.content')); ?></label>
            
            <textarea name="content" required id="summernote"></textarea>
          </div>
        </div>
      </div>

      <div class="mt-3">
        <button class="btn btn-primary" id="submit" disabled><?php echo e(__('general.submit')); ?></button>
      </div>

    </form>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(() => {
        $('#summernote').summernote({
          placeholder: '',
          height: 100,
          callbacks: {
            onKeydown: function(e) {
              $('#submit').removeAttr('disabled')
            }
          },
        });
        $("#summernote").summernote("code", `<?php echo $privacy->content; ?>`)
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/privacy/index.blade.php ENDPATH**/ ?>