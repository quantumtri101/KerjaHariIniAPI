<div class="row">
  <div class="col-12">
    <div id="calendar"></div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var jobs_datatable = null
  var calendar = null

  function reload_calendar(){
    if(calendar == null){
      var context = this
      calendar = new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'dayGridMonth',
        eventClick: (info) => {
          if(info.event.id != '<?php echo e($event->id); ?>'){
            save_current_page('<?php echo e(__("event.detail")); ?>')
            location.href = '<?php echo e(url("/jobs/detail")); ?>?id=' + info.event.id
          }
        },
      })
      
      setTimeout(() => {
        
        calendar.render()

        calendar.addEvent({
          id: '<?php echo e($event->id); ?>',
          title: '<?php echo e($event->name); ?>',
          start: '<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>',
          end: '<?php echo e($event->end_date->addDays(1)->formatLocalized("%Y-%m-%d")); ?>',
          color: '#44A244',
        })

        <?php $__currentLoopData = $event->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          calendar.addEvent({
            id: '<?php echo e($jobs->id); ?>',
            title: '<?php echo e($jobs->name); ?>',
            start: '<?php echo e($jobs->start_shift->start_date->formatLocalized("%Y-%m-%d")); ?>',
            end: '<?php echo e($jobs->end_shift->end_date->addDays(1)->formatLocalized("%Y-%m-%d")); ?>',
            color: '#44A244',
          })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        // console.log()
        calendar.gotoDate(moment('<?php echo e($event->start_date->formatLocalized("%Y-%m-%d")); ?>', 'YYYY-MM-DD').toDate());
      }, 100);
    }
  }

  $(document).ready(function () {
    

    
  })
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/event/component/calendar.blade.php ENDPATH**/ ?>