<div>
  <div class="mt-3 table-responsive">
    <table class="table w-100" id="list_shift_datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.start_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.end_date')); ?></th>
          
        </tr>
      </thead>
    </table>
  </div>
</div>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var user_datatable = null

  $(document).ready(function () {
    user_datatable = $('#list_shift_datatable').DataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : "<?php echo e(url('api/jobs/shift')); ?>?jobs_id=<?php echo e($jobs->id); ?>",
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "name", name: "name"},
        {"data" : "start_date_format", name: "start_date"},
        {"data" : "end_date_format", name: "end_date"},
      ],
      "columnDefs" : [
        // {
        //   targets: -1,
        //   data: null,
        //   sorting: false,
        //   render: function(data, type, row, meta) {
        //     var json = JSON.stringify(row)
        //     var arr_application = []
        //     var flag = false
        //     var application = null
        //     <?php $__currentLoopData = $jobs->application; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        //       arr_application.push({
        //         id: '<?php echo e($application->id); ?>',
        //         user_id: '<?php echo e($application->user_id); ?>',
        //       })
        //     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        //     for(let application1 of arr_application){
        //       if(row.id === application1.user_id){
        //         flag = true
        //         application = application1
        //         break
        //       }
        //     }
            
        //     var str = ""
        //     str += '<div style="">'
        //       // if(!flag && <?php echo e($jobs->num_people_required > count($jobs->application) ? 'true' : 'false'); ?> && <?php echo e($jobs->is_approve == 1 ? 'true' : 'false'); ?>)
        //       //   str += `
        //       //     <form method="POST" class="d-inline-block" action="<?php echo e(url('/jobs/application')); ?>">
        //       //       <?php echo csrf_field(); ?>
        //       //       <input type="hidden" name="user_id" value="${row.id}"/>
        //       //       <input type="hidden" name="jobs_id" value="<?php echo e($jobs->id); ?>"/>
        //       //       <input type="hidden" name="is_approve_corp" value="1"/>
        //       //       <button class="btn btn-primary">
        //       //         <?php echo e(__('general.set_applied')); ?>

        //       //       </button>
        //       //     </form>
        //       //   `

        //       str += `
        //         <button class="btn btn-primary" onclick="view_resume('${row.id}', '${application != null ? application.id : ''}', ${application != null})" ${row.resume.length == 0 ? 'disabled' : ''}><?php echo e(__('general.view_resume')); ?></button>
        //       `
        //     str += '</div>'
        //     return str
        //   },
        // },
      ]
    })
  })
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/list_shift.blade.php ENDPATH**/ ?>