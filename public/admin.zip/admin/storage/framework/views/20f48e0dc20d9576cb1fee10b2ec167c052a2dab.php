

<?php $__env->startSection('content'); ?>
<div>
  <p class="text-center">ABSENSI PERIODE <?php echo e($jobs_shift->start_date->formatLocalized('%d %B %Y')); ?></p>
  <p class="text-center"><?php echo e($jobs_shift->jobs->name); ?></p>
</div>

<div>
  <table class="table table-striped">
    <thead>
      <tr>
        <th colspan="6" class="text-center"><?php echo e($jobs_shift->start_date->formatLocalized('%d %B %Y')); ?></th>
      </tr>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>NIK</th>
        <th>Nomor HP</th>
        <th>Masuk</th>
        <th>Keluar</th>
      </tr>
    </thead>
    <tbody>
      <?php if(count($arr_check_log) > 0): ?>
        <?php $__currentLoopData = $arr_check_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $check_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($check_log->user->name); ?></td>
            <td><?php echo e($check_log->user->id_no); ?></td>
            <td><?php echo e($check_log->user->phone); ?></td>
            <td><?php echo e($check_log->date->formatLocalized('%d %B %Y %H:%M')); ?></td>
            <td><?php echo e($check_log->check_out->date->formatLocalized('%d %B %Y %H:%M')); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
        <tr>
          <td colspan="6" class="text-center"><?php echo e(__('general.no_data')); ?></td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('exports.base_export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/exports/check_log_shift_pdf.blade.php ENDPATH**/ ?>