

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.staff'),
      __('staff.detail'),
      __('staff.edit'),
    ] : [
      __('general.staff'),
      __('staff.add'),
    ],
    "title" => Request::has('id') ? __('staff.edit') : __('staff.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('staff.edit') : __('staff.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/user/staff/edit' : '/user/staff')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="row">
          <div class="col-12 col-lg-4">
            <?php echo $__env->make('layout.upload_photo', [
              'data' => $user,
              'url_image' => '/image/user',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          <div class="col-12 col-lg-8">
            <div class="form-group">
              <label><?php echo e(__('general.status_active')); ?></label>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="is_active" value="1" id="defaultCheckActive" required <?php echo e(!empty($user) && $user->is_active == '1' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="defaultCheckActive">
                  <?php echo e(__('general.active')); ?>

                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="is_active" value="0" id="defaultCheckInactive" required <?php echo e(!empty($user) && $user->is_active == '0' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="defaultCheckInactive">
                  <?php echo e(__('general.inactive')); ?>

                </label>
              </div>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.company')); ?></label>
              <select required name="company_id" <?php echo e(!empty(Auth::user()->company) ? 'disabled' : ''); ?> class="form-control">
                <?php $__currentLoopData = $arr_company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->id); ?>" <?php echo e((!empty(Auth::user()->company) && Auth::user()->company->id == $company->id) || (empty(Auth::user()->company) && !empty($user) && $user->company->id == $company->id) ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.company_position')); ?></label>
              <select required name="company_position_id" class="form-control">
                <?php $__currentLoopData = $arr_company_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company_position->id); ?>" <?php echo e(!empty($user) && $user->company_position->id == $company_position->id ? 'selected' : ''); ?>><?php echo e($company_position->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.sub_category')); ?></label>
              <select required name="sub_category_id" class="form-control">
                <?php $__currentLoopData = $arr_sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sub_category->id); ?>" <?php echo e(!empty($user) && !empty($user->sub_category) && $user->sub_category->id == $sub_category->id ? 'selected' : ''); ?>><?php echo e($sub_category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.name')); ?></label>
              <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($user) ? $user->name : ''); ?>"/>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.email')); ?></label>
              <input type="email" required name="email" class="form-control" value="<?php echo e(!empty($user) ? $user->email : ''); ?>"/>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.phone')); ?></label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="basic-addon1"><?php echo e(__('general.code_area')); ?></span>
                </div>
                <input type="text" required name="phone" id="phone" class="form-control" value="<?php echo e(!empty($user) ? $user->phone : ''); ?>"/>
              </div>
            </div>

            <div class="form-group">
              <label><?php echo e(__('general.gender')); ?></label>
              <select required name="gender" class="form-control">
                <option value="1" <?php echo e(!empty($user) && $user->gender == 1 ? 'selected' : ''); ?>><?php echo e(__('general.male')); ?></option>
                <option value="0" <?php echo e(!empty($user) && $user->gender == 0 ? 'selected' : ''); ?>><?php echo e(__('general.female')); ?></option>
              </select>
            </div>
          </div>

          <div class="col-12 mt-3">
            <div class="form-group" >
              <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
              <button class="btn btn-primary" id="submit" onclick="back_page(false)"><?php echo e(__('general.submit')); ?></button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>

      $(document).ready(() => {

        $('#phone').keyup(() => {
          $('#phone').val(phone_validation($('#phone').val()))
        })

        // init_birth_date()
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/staff/action.blade.php ENDPATH**/ ?>