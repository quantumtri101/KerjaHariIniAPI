<div class="modal fade" id="edit_check_log_date" data-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('general.edit_check_log_date')); ?></h5>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/check-log/edit')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="jobs_shift_id" value="<?php echo e($jobs_shift->id); ?>"/>
          <input type="hidden" name="user_id" id="check_log_date_user_id"/>
          

          <div class="form-group">
            <label><?php echo e(__('general.check_in_date')); ?></label>
            <input type="text" id="checkindatetimepicker" name="check_in_date" class="form-control" data-toggle="datetimepicker" data-target="#checkindatetimepicker"/>
          </div>

          <div class="form-group">
            <label><?php echo e(__('general.check_out_date')); ?></label>
            <input type="text" id="checkoutdatetimepicker" name="check_out_date" class="form-control" data-toggle="datetimepicker" data-target="#checkoutdatetimepicker"/>
          </div>

          

          <div>
            <button type="submit" class="btn btn-primary" >Submit</button>
            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    var checkindatetimepicker = null
    var checkoutdatetimepicker = null
    var jobsShiftMinDate = moment('<?php echo e($jobs_shift->start_date->formatLocalized("%d-%m-%Y %H:%M")); ?>', 'DD-MM-YYYY HH:mm')
    var jobsShiftMaxDate = moment('<?php echo e($jobs_shift->end_date->formatLocalized("%d-%m-%Y %H:%M")); ?>', 'DD-MM-YYYY HH:mm')

    function init_check_in_date(){
      if(checkindatetimepicker != null)
        $('#checkindatetimepicker').datetimepicker('destroy')
      console.log(jobsShiftMinDate)
      checkindatetimepicker = $('#checkindatetimepicker').datetimepicker({
        format: 'DD-MM-YYYY HH:mm',
        useCurrent: false,
        defaultDate: moment($('#checkindatetimepicker').val(), 'DD-MM-YYYY HH:mm'),
        minDate: jobsShiftMinDate,
        maxDate: $('#checkoutdatetimepicker').val() != "" ? moment($('#checkoutdatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment($('#checkindatetimepicker').val(), 'DD-MM-YYYY HH:mm').add(1, 'h'),
        icons: {
          time: 'fa-solid fa-clock',
          date: 'fa-solid fa-calendar',
        },
      })

      $('#checkindatetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
        if(oldDate != null){
          init_check_out_date()
        }
      })
    }

    function init_check_out_date(){
      if(checkoutdatetimepicker != null)
        $('#checkoutdatetimepicker').datetimepicker('destroy')
      checkoutdatetimepicker = $('#checkoutdatetimepicker').datetimepicker({
        format: 'DD-MM-YYYY HH:mm',
        useCurrent: false,
        defaultDate: $('#checkoutdatetimepicker').val() != "" ? moment($('#checkoutdatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment($('#checkindatetimepicker').val(), 'DD-MM-YYYY HH:mm').add(1, 'h'),
        minDate: $('#checkindatetimepicker').val() != "" ? moment($('#checkindatetimepicker').val(), 'DD-MM-YYYY HH:mm') : moment($('#checkindatetimepicker').val(), 'DD-MM-YYYY HH:mm').add(1, 'h'),
        maxDate: jobsShiftMaxDate,
        icons: {
          time: 'fa-solid fa-clock',
          date: 'fa-solid fa-calendar',
        },
      })

      $('#checkoutdatetimepicker').on("change.datetimepicker", ({date, oldDate}) => {
        if(oldDate != null){
          init_check_in_date()
        }
      })
    }

    $(document).ready(function() {
      
    })
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/modal/edit_check_log_date.blade.php ENDPATH**/ ?>