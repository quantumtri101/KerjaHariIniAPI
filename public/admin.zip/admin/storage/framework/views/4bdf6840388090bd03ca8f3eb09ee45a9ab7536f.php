<div class="modal fade" id="edit_salary_verification" data-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('general.edit_salary_verification')); ?></h5>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/salary/edit/salary')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="jobs_shift_id" id="salary_jobs_shift_id"/>
          <input type="hidden" name="user_id" id="salary_user_id"/>

          <div class="form-group">
            <label><?php echo e(__('general.salary')); ?></label>
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text" id="basic-addon1">Rp.</span>
              </div>
              <input type="text" id="salary_salary_verification" name="salary" class="form-control"/>
            </div>
          </div>

          <div>
            <button type="submit" class="btn btn-primary" >Submit</button>
            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>

    $(document).ready(function() {
      $('#salary_salary_verification').keyup(() => {
        $('#salary_salary_verification').val(to_currency_format($('#salary_salary_verification').val()))
      })
    })
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/modal/edit_salary_verification.blade.php ENDPATH**/ ?>