

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.request_withdraw'),
    ],
    "title" => __('request_withdraw.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('request_withdraw.title')); ?></h5>

    
  </div>

  <div class="mt-3">
    <table class="table" id="datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.user_name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.total_amount_salary')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.created_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.action')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<?php echo $__env->make('layout.modal.decline_request_withdraw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.set_approve_request_withdraw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  function showDeclineModal(request_withdraw_id){
    $('#request_withdraw_decline_id').val(request_withdraw_id)
    $('#request_withdraw_decline_modal').modal('show')
  }

  function showApproveModal(request_withdraw_id){
    $('#request_withdraw_approve_id').val(request_withdraw_id)
    $('#request_withdraw_approve_modal').modal('show')
  }

  $(document).ready(async function () {
    
    datatable = $('#datatable').dataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: 'Bfrtip',
      buttons: [
        // {
        //   className: 'btn btn-primary',   
        //   text : "<?php echo e(__('general.add')); ?>",
        //   action: function ( e, dt, node, config ) {
        //     save_current_page('<?php echo e(__('request_withdraw.title')); ?>')
        //     location.href = "<?php echo e(url('/jobs/recommendation/action')); ?>"
        //   },
        //   init: function(api, node, config) {
        //     $(node).removeClass('dt-button')
        //   },
        // },
      ],
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : "<?php echo e(url('api/request-withdraw')); ?>",
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "user_name", name: "user.name"},
        {"data" : "total_amount_format", name: "total_amount"},
        {"data" : "date_format", name: "date"},
        {"data" : "status_approve_format", name: "is_approve"},
        {"data" : "action", "orderable" : false},
      ],
      "columnDefs" : [
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var str = ""
            str += '<div>'
              str += `<a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('request_withdraw.title')); ?>')" href="<?php echo e(url('/request-withdraw/detail')); ?>?id=${row.id}")><?php echo e(__('general.detail')); ?></a>`
              if(row.status == 'requested'){
                str += `
                  <button class="btn btn-primary" onclick="showApproveModal('${row.id}')"><?php echo e(__('general.set_approve')); ?></button>
                  <button class="btn btn-primary ml-1" onclick="showDeclineModal('${row.id}')"><?php echo e(__('general.set_decline')); ?></button>

                  <a class="btn btn-danger ml-1 d-inline-block" href="#!" onclick="alertDelete('<?php echo e(url('/request-withdraw/delete')); ?>?id=${row.id}')">Delete</a>
                `
              }
            str += '</div>'
            return str
          },
        },
      ]
    })
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/request_withdraw/index.blade.php ENDPATH**/ ?>