<div class="row">
  <div class="col-12 col-lg-4">
    <div>
      <label><?php echo e(__('general.vaccine_covid')); ?></label>
      <?php echo $__env->make('layout.upload_photo', [
        "column" => "vaccine_covid_file_name",
        "form_name" => "vaccine_covid_image",
        "data" => $user,
        "id" => "vaccine_covid_image",
        "url_image" => "/image/user/vaccine-covid",
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="mt-3">
      <label><?php echo e(__('general.cv')); ?></label>
      <?php echo $__env->make('layout.upload_photo', [
        "column" => "cv_file_name",
        "form_name" => "cv_image",
        "data" => $user,
        "id" => "cv_image",
        "url_image" => "/image/user/cv",
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <div class="col-12 col-lg-8">
    <div class="form-group">
      <label><?php echo e(__('general.birth_date')); ?></label>
      <input type="text" required name="birth_date" id="birthdatetimepicker" class="form-control" value="<?php echo e(!empty($user) && count($user->resume) > 0 ? $user->birth_date : ''); ?>" data-toggle="datetimepicker" data-target="#birthdatetimepicker"/>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.address')); ?></label>
      <textarea required name="address" id="address" class="form-control"><?php echo e(!empty($user) && count($user->resume) > 0 ? $user->resume[0]->address : ''); ?></textarea>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.city')); ?></label>
      <select required name="city_id" class="form-control" id="city"></select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.marital_status')); ?></label>
      <select required name="marital_status" class="form-control" id="marital_status">
        <option value=""><?php echo e(__('general.choose_marital_status')); ?></option>
        <?php $__currentLoopData = $arr_marital_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marital_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($marital_status['id']); ?>" <?php echo e(!empty($user) && count($user->resume) > 0 && $marital_status['id'] == $user->resume[0]->marital_status ? 'selected' : ''); ?>><?php echo e(__('general.'.$marital_status['id'])); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="row">
      <div class="col-6">
        <div class="form-group">
          <label><?php echo e(__('general.height')); ?></label>
          <div class="input-group mb-3">
            <input type="text" required name="height" id="height" class="form-control" value="<?php echo e(!empty($user) && count($user->resume) > 0 ? $user->resume[0]->height : ''); ?>"/>
            <div class="input-group-append">
              <span class="input-group-text" id="basic-addon1">cm</span>
            </div>
          </div>
        </div>
      </div>

      <div class="col-6">
        <div class="form-group">
          <label><?php echo e(__('general.weight')); ?></label>
          <div class="input-group mb-3">
            <input type="text" required name="weight" id="weight" class="form-control" value="<?php echo e(!empty($user) && count($user->resume) > 0 ? $user->resume[0]->weight : ''); ?>"/>
            <div class="input-group-append">
              <span class="input-group-text" id="basic-addon1">kg</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.education')); ?></label>
      <select required name="education_id" class="form-control" id="education"></select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.bank')); ?></label>
      <select required name="bank_id" class="form-control" id="bank"></select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.acc_no')); ?></label>
      <input type="text" required name="acc_no" class="form-control" value="<?php echo e(!empty($user) && count($user->resume) > 0 ? $user->resume[0]->acc_no : ''); ?>"/>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    function check_resume(){
      var message = ""
      
      if(!$('#radio-active').is(':checked') && !$('#radio-inactive').is(':checked'))
        message = "<?php echo e(__('general.status_active_not_choosen')); ?>"
      else if($('#birthdatetimepicker').val() == "")
        message = "<?php echo e(__('general.birth_date_empty')); ?>"
      else if($('#address').val() == "")
        message = "<?php echo e(__('general.address_empty')); ?>"
      else if($('#city').val() == "")
        message = "<?php echo e(__('general.city_not_choosen')); ?>"
      else if($('#marital_status').val() == "")
        message = "<?php echo e(__('general.marital_status_not_choosen')); ?>"
      else if($('#height').val() == "" || $('#height').val() == "0")
        message = "<?php echo e(__('general.height_empty')); ?>"
      else if($('#weight').val() == "" || $('#weight').val() == "0")
        message = "<?php echo e(__('general.weight_empty')); ?>"
      else if($('#education').val() == "")
        message = "<?php echo e(__('general.education_not_choosen')); ?>"
      else if($('#bank').val() == "")
        message = "<?php echo e(__('general.bank_not_choosen')); ?>"
      else if($('#acc_no').val() == "")
        message = "<?php echo e(__('general.acc_no_empty')); ?>"
      return message
    }
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
$('#height').keyup(() => {
  $('#height').val(to_currency_format($('#height').val()))
})
$('#width').keyup(() => {
  $('#width').val(to_currency_format($('#width').val()))
})
$('#birthdatetimepicker').datetimepicker({
  format: 'DD-MM-YYYY',
  maxDate: moment().subtract(20, 'years'),
})
$('#city').select2({
  ajax: {
    url: '<?php echo e(url('/api/city/all')); ?>',
    dataType: 'json',
    processResults: function (data) {
      // Transforms the top-level key of the response object from 'items' to 'results'
      return {
        results: data.data
      };
    }
  },
})
$('#education').select2({
  ajax: {
    url: '<?php echo e(url('/api/education/all')); ?>',
    dataType: 'json',
    processResults: function (data) {
      // Transforms the top-level key of the response object from 'items' to 'results'
      return {
        results: data.data
      };
    }
  },
})
$('#bank').select2({
  ajax: {
    url: '<?php echo e(url('/api/bank/all')); ?>',
    dataType: 'json',
    processResults: function (data) {
      // Transforms the top-level key of the response object from 'items' to 'results'
      return {
        results: data.data
      };
    }
  },
})

<?php if(!empty($user) && count($user->resume) > 0): ?>
  $('#city').html(`<option value="<?php echo e($user->resume[0]->city->id); ?>" selected><?php echo e($user->resume[0]->city->name); ?></option>`)
  $('#education').html(`<option value="<?php echo e($user->resume[0]->education->id); ?>" selected><?php echo e($user->resume[0]->education->name); ?></option>`)
  $('#bank').html(`<option value="<?php echo e($user->resume[0]->bank->id); ?>" selected><?php echo e($user->resume[0]->bank->name); ?></option>`)
<?php endif; ?>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/action/resume_info.blade.php ENDPATH**/ ?>