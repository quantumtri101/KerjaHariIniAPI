<div class="row">
  <div class="col-12 col-lg-8">
    <div class="row">
      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.id')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->id); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.start_date')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->start_date->formatLocalized('%d %B %Y %H:%M')); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.end_date')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->end_date->formatLocalized('%d %B %Y %H:%M')); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.company')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->company->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.company_phone')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->company->phone); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 col-lg-4">
    <div class="form-group">
      <label for="exampleInputEmail1"><?php echo e(__('general.image')); ?></label>
      <div>
        <?php $__currentLoopData = $event->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img src="<?php echo e(url('/image/event?file_name='.$image->file_name)); ?>" width="50%"/>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    <a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('event.detail')); ?>')" href="<?php echo e(url('/event/action?id='.$event->id)); ?>"><?php echo e(__('general.edit')); ?></a>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/event/component/general_info.blade.php ENDPATH**/ ?>