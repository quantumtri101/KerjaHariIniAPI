

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.report_monthly'),
    ],
    "title" => __('report_monthly.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('report_monthly.title')); ?></h5>

    
  </div>

  <div class="card">
    <div class="card-body">
      <canvas id="chartBar1" height="50"></canvas>
    </div>
  </div>

  <div class="mt-3 table-responsive">
    <table class="table table-bordered bg-white" id="datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.month')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.total_expense')); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $arr_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($month['date_text']); ?></td>
            <td>Rp. <?php echo e(number_format($month['total_expense'], 0, ',', '.')); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  $(document).ready(async function () {
    var ctx = document.getElementById('chartBar1').getContext('2d');
    var arr_label = []
    var arr_datasets = []
    var arr = []

    <?php $__currentLoopData = $arr_month; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      arr_label.push('<?php echo e($month['date_text']); ?>')
      arr.push(<?php echo e($month['total_expense']); ?>)
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    arr_datasets.push(
      {
        label: '<?php echo e(__('general.total_expense')); ?>',
        data: arr,
        backgroundColor: '#27AAC8'
      }
    )

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: arr_label,
        datasets: arr_datasets
      },
      options: {
        legend: {
          display: false,
            labels: {
              display: false
            }
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero:true,
              fontSize: 10,
              max: 80
            }
          }],
          xAxes: [{
            ticks: {
              beginAtZero:true,
              fontSize: 11
            }
          }]
        }
      }
    });
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/report/monthly/index.blade.php ENDPATH**/ ?>