<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-12">
        <div class="row">
          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.id')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->id); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.name')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->name); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.user_name')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->user->name); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.category_name')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->sub_category->category->name); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.sub_category_name')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->sub_category->name); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.event_name')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->event->name); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.description')); ?></label>
              <textarea class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled><?php echo e($jobs->description); ?></textarea>
            </div>
          </div>

          

          

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.status_urgent')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(__('general.'.($jobs->is_urgent == 1 ? 'urgent' : 'not_urgent'))); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.type')); ?></label>
              <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(__('general.'.$jobs->staff_type)); ?>" aria-describedby="emailHelp" disabled>
            </div>
          </div>

          

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.salary_regular')); ?></label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="basic-addon1">Rp.</span>
                </div>
                <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(number_format($jobs->salary_regular, 0, ',', '.')); ?>" aria-describedby="emailHelp" disabled>
                <div class="input-group-append <?php echo e($jobs->salary_type_regular == "per_hour" ? '' : 'd-none'); ?>">
                  <span class="input-group-text" id="basic-addon1">/ Hour</span>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.salary_casual')); ?></label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text" id="basic-addon1">Rp.</span>
                </div>
                <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(number_format($jobs->salary_casual, 0, ',', '.')); ?>" aria-describedby="emailHelp" disabled>
                <div class="input-group-append <?php echo e($jobs->salary_type_casual == "per_hour" ? '' : 'd-none'); ?>">
                  <span class="input-group-text" id="basic-addon1">/ Hour</span>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.benefit')); ?></label>
              <textarea class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" disabled><?php echo e($jobs->benefit); ?></textarea>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.num_people_required')); ?></label>
              <div class="input-group">
                <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(number_format($jobs->num_people_required, 0, ',', '.')); ?>" aria-describedby="emailHelp" disabled>
                <div class="input-group-append">
                  <span class="input-group-text" id="basic-addon1">Person</span>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1"><?php echo e(__('general.status_on_app')); ?></label>
              <div>
                <span class="bg-<?php echo e($jobs->is_available_shift && $jobs->is_live_app == 1 ? 'success' : 'danger'); ?> pd-y-3 pd-x-10 tx-white tx-11 tx-roboto"><?php echo e(__('general.'.($jobs->is_available_shift ? ($jobs->is_live_app == 1 ? 'live' : 'not_live') : 'ended'))); ?></span>
              </div>
            </div>
          </div>

          <?php if(!empty($jobs->publish_start_at)): ?>
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label for="exampleInputEmail1"><?php echo e(__('general.publish_start_date')); ?></label>
                <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->publish_start_at->formatLocalized('%d %B %Y')); ?>" aria-describedby="emailHelp" disabled>
              </div>
            </div>
          <?php endif; ?>

          <?php if(!empty($jobs->publish_end_at)): ?>
            <div class="col-12 col-lg-6">
              <div class="form-group">
                <label for="exampleInputEmail1"><?php echo e(__('general.publish_end_date')); ?></label>
                <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs->publish_end_at->formatLocalized('%d %B %Y')); ?>" aria-describedby="emailHelp" disabled>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="col-12 d-flex mt-3">
        <?php if(Auth::user()->type->name == "admin" || Auth::user()->type->name == "RO"): ?>
          <?php if($jobs->is_available_shift): ?>
            <a class="btn btn-primary mr-3" onclick="save_current_page('<?php echo e(__('jobs.detail')); ?>')" href="<?php echo e(url('/jobs/action?id='.$jobs->id)); ?>"><?php echo e(__('general.edit')); ?></a>
          <?php endif; ?>

          
          

          <?php if($jobs->is_approve == 1 && $jobs->shift[0]->start_date > \Carbon\Carbon::now()): ?>
            <?php if($jobs->is_live_app == 1): ?>
              <form method="post" action="<?php echo e(url('/jobs/change-live')); ?>" class="d-inline-block ml-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="jobs_id" value="<?php echo e($jobs->id); ?>"/>
                <input type="hidden" name="is_live_app" value="0"/>
                <button class="btn btn-primary"><?php echo e(__('general.change_not_live')); ?></button>
              </form>
            <?php else: ?>
              <form method="post" id="jobsForm" action="<?php echo e(url('/jobs/change-live')); ?>" class="d-inline-block ml-3">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="jobs_id" value="<?php echo e($jobs->id); ?>"/>
                <input type="hidden" name="publish_start_date" id="publish_start_date"/>
                <input type="hidden" name="publish_end_date" id="publish_end_date"/>
              </form>
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#publish_date_choose_staff"><?php echo e(__('general.change_live')); ?></button>
            <?php endif; ?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php if($jobs->is_approve == 1 && $jobs->shift[0]->start_date > \Carbon\Carbon::now()): ?>
  <?php echo $__env->make('layout.modal.publish_date_choose_staff', [
    "type" => "detail",
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/general_info.blade.php ENDPATH**/ ?>