<div class="row">
  <div class="col-12">
    <div class="form-group">
      <label><?php echo e(__('general.gender')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="gender" value="<?php echo e($jobs->criteria[0]->gender); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" value="male" <?php echo e(!empty($jobs) && $jobs->criteria[0]->gender == 'male' ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-male">
        <label class="form-check-label" for="radio-male">
          <?php echo e(__('general.male')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" value="female" <?php echo e(!empty($jobs) && $jobs->criteria[0]->gender == 'female' ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-female">
        <label class="form-check-label" for="radio-female">
          <?php echo e(__('general.female')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="gender" value="both" <?php echo e(!empty($jobs) && $jobs->criteria[0]->gender == 'both' ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-both">
        <label class="form-check-label" for="radio-both">
          <?php echo e(__('general.both')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.education')); ?></label>
      <select name="education_id" id="education_id" class="form-control" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>>
        <option value=""><?php echo e(__('general.choose_education')); ?></option>
        <?php $__currentLoopData = $arr_education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($education->id); ?>" <?php echo e(!empty($jobs) && $education->id == $jobs->criteria[0]->education->id ? 'selected' : ''); ?>><?php echo e($education->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.age_range')); ?></label>
      <div class="row">
        <div class="col">
          <input type="text" name="min_age" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="min_age" class="form-control" value="<?php echo e(!empty($jobs) ? $jobs->criteria[0]->min_age : ''); ?>"/>
        </div>
        <div class="col">
          <input type="text" name="max_age" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="max_age" class="form-control" value="<?php echo e(!empty($jobs) ? $jobs->criteria[0]->max_age : ''); ?>"/>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.has_pkwt')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="has_pkwt" value="<?php echo e($jobs->criteria[0]->has_pkwt); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="has_pkwt" value="1" <?php echo e(!empty($jobs) && $jobs->criteria[0]->has_pkwt == 1 ? 'checked' : ''); ?> id="radio-pkwt-yes">
        <label class="form-check-label" for="radio-pkwt-yes">
          <?php echo e(__('general.yes')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="has_pkwt" value="0" <?php echo e(!empty($jobs) && $jobs->criteria[0]->has_pkwt == 0 ? 'checked' : ''); ?> id="radio-pkwt-no">
        <label class="form-check-label" for="radio-pkwt-no">
          <?php echo e(__('general.no')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.has_pkhl')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="has_pkhl" value="<?php echo e($jobs->criteria[0]->has_pkhl); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="has_pkhl" value="1" <?php echo e(!empty($jobs) && $jobs->criteria[0]->has_pkhl == 1 ? 'checked' : ''); ?> id="radio-pkhl-yes">
        <label class="form-check-label" for="radio-pkhl-yes">
          <?php echo e(__('general.yes')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="has_pkhl" value="0" <?php echo e(!empty($jobs) && $jobs->criteria[0]->has_pkhl == 0 ? 'checked' : ''); ?> id="radio-pkhl-no">
        <label class="form-check-label" for="radio-pkhl-no">
          <?php echo e(__('general.no')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.is_working_same_company')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="is_working_same_company" value="<?php echo e($jobs->criteria[0]->is_working_same_company); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="is_working_same_company" value="1" <?php echo e(!empty($jobs) && $jobs->criteria[0]->is_working_same_company == 1 ? 'checked' : ''); ?> id="radio-working_same-yes">
        <label class="form-check-label" for="radio-working_same-yes">
          <?php echo e(__('general.yes')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="is_working_same_company" value="0" <?php echo e(!empty($jobs) && $jobs->criteria[0]->is_working_same_company == 0 ? 'checked' : ''); ?> id="radio-working_same-no">
        <label class="form-check-label" for="radio-working_same-no">
          <?php echo e(__('general.no')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.working_area')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="arr_working_area_json" value="<?php echo e(json_encode($jobs->arr_working_area)); ?>" />
      <?php endif; ?>
      <select class="form-control select2" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="working_area" name="working_area[]" data-placeholder="Choose City" multiple="multiple">
        <?php $__currentLoopData = $arr_working_area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $working_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($working_area->id); ?>" <?php echo e($working_area->is_selected ? 'selected' : ''); ?>><?php echo e($working_area->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group d-none">
      <label><?php echo e(__('general.is_same_place')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="is_same_place" value="<?php echo e($jobs->criteria[0]->is_same_place); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="is_same_place" value="1" <?php echo e(!empty($jobs) && $jobs->criteria[0]->is_same_place == 1 ? 'checked' : ''); ?> id="radio-same_place-yes">
        <label class="form-check-label" for="radio-same_place-yes">
          <?php echo e(__('general.yes')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> type="radio" name="is_same_place" value="0" <?php echo e(!empty($jobs) && $jobs->criteria[0]->is_same_place == 0 ? 'checked' : ''); ?> id="radio-same_place-no">
        <label class="form-check-label" for="radio-same_place-no">
          <?php echo e(__('general.no')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.other_criteria')); ?></label>
      <textarea name="other_criteria" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="other_criteria" class="form-control"><?php echo e(!empty($jobs) ? $jobs->criteria[0]->other_criteria : ''); ?></textarea>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    function check_criteria(){
      var message = ""
      if(!$('#radio-male').is(':checked') && !$('#radio-female').is(':checked') && !$('#radio-both').is(':checked'))
        message = "<?php echo e(__('general.gender_not_choosen')); ?>"
      else if($('#education_id').val() == "")
        message = "<?php echo e(__('general.education_not_choosen')); ?>"
      else if($('#min_age').val() == "" || $('#min_age').val() == "0")
        message = "<?php echo e(__('general.min_age_empty')); ?>"
      else if($('#max_age').val() == "" || $('#max_age').val() == "0")
        message = "<?php echo e(__('general.max_age_empty')); ?>"
      else if(!$('#radio-pkwt-yes').is(':checked') && !$('#radio-pkwt-no').is(':checked'))
        message = "<?php echo e(__('general.has_pkwt_not_choosen')); ?>"
      else if(!$('#radio-pkhl-yes').is(':checked') && !$('#radio-pkhl-no').is(':checked'))
        message = "<?php echo e(__('general.has_pkhl_not_choosen')); ?>"
      else if(!$('#radio-working_same-yes').is(':checked') && !$('#radio-working_same-no').is(':checked'))
        message = "<?php echo e(__('general.working_same_company_not_choosen')); ?>"
      else if($('#working_area').val() == "")
        message = "<?php echo e(__('general.working_area_empty')); ?>"
      // else if(!$('#radio-same_place-yes').is(':checked') && !$('#radio-same_place-no').is(':checked'))
      //   message = "<?php echo e(__('general.same_place_not_choosen')); ?>"
      return message
    }

    $(document).ready(() => {
      
    })
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
$('#working_area').select2()

$('#salary_regular').keyup(() => {
  $('#salary_regular').val(to_currency_format($('#salary_regular').val()))
})
$('#salary_casual').keyup(() => {
  $('#salary_casual').val(to_currency_format($('#salary_casual').val()))
})
$('#min_age').keyup(() => {
  min_age = str_to_double($('#min_age').val())
  max_age = str_to_double($('#max_age').val())

  $('#min_age').val(to_currency_format($('#min_age').val()))
  if(min_age > max_age)
    $('#max_age').val(to_currency_format($('#min_age').val()))
})
$('#max_age').keyup(() => {
  min_age = str_to_double($('#min_age').val())
  max_age = str_to_double($('#max_age').val())

  $('#max_age').val(to_currency_format($('#max_age').val()))
  if(min_age > max_age)
    $('#min_age').val(to_currency_format($('#max_age').val()))
})
$('#radio-yes').click(() => {
  $('#with_split_shift').removeClass('d-none')
  $('#without_split_shift').addClass('d-none')
})
$('#radio-no').click(() => {
  $('#with_split_shift').addClass('d-none')
  $('#without_split_shift').removeClass('d-none')
})
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/action/criteria_info.blade.php ENDPATH**/ ?>