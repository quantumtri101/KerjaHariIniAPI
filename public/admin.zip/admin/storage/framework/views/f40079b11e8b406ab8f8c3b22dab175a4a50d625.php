
<table>
  <thead>
    <tr>
      <td colspan="7">ABSENSI KARYAWAN</td>
    </tr>
    <tr>
      <td colspan="7"><?php echo e($jobs_shift->jobs->name); ?></td>
    </tr>
    <tr>
      <td colspan="7">Periode <?php echo e($jobs_shift->start_date->formatLocalized('%d %B').' - '.$jobs_shift->end_date->formatLocalized('%d %B %Y')); ?></td>
    </tr>
    <tr>
      <th>No</th>
      <th>NIK KTP</th>
      <th>Nama</th>
      <th>Nomor HP</th>
      <th>Jabatan</th>
      <th>In</th>
      <th>Out</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $arr_check_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $check_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($key + 1); ?></td>
        <td><?php echo e($check_log->user->id_no); ?></td>
        <td><?php echo e($check_log->user->name); ?></td>
        <td><?php echo e($check_log->user->phone); ?></td>
        <td><?php echo e(__('general.'.$check_log->user->type->name)); ?></td>
        <td><?php echo e($check_log->date->formatLocalized('%d %B %Y %H:%M')); ?></td>
        <td><?php echo e($check_log->check_out->date->formatLocalized('%d %B %Y %H:%M')); ?></td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/exports/check_log_shift.blade.php ENDPATH**/ ?>