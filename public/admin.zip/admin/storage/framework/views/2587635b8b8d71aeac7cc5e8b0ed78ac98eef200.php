<div class="br-header">
    <div class="br-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="fa-solid fa-bars"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="fa-solid fa-bars"></i></a></div>
        
    </div><!-- br-header-left -->

    <nav class="nav">
        <div class="dropdown">
            <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
              <div class="d-flex align-items-center">
                <div class="mr-1">
                  <div class="logged-name hidden-md-down d-block"><?php echo e(Auth::user()->name); ?></div>
                  <?php if(Auth::user()->type->name != "admin"): ?>
                    <div class="logged-name hidden-md-down  d-block"><?php echo e(Auth::user()->company->name); ?></div>
                  <?php endif; ?>
                </div>
                <img src="<?php echo e(!empty(Auth::user()->file_name) ? url('/image/user?file_name='.Auth::user()->file_name) : $url_asset.'/image/blank_profile_picture.webp'); ?>" class="wd-32 rounded-circle" alt="">
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-header wd-250">
              <div class="tx-center mt-3">
                <a href=""><img src="<?php echo e(!empty(Auth::user()->file_name) ? url('/image/user?file_name='.Auth::user()->file_name) : $url_asset.'/image/blank_profile_picture.webp'); ?>" class="wd-80 rounded-circle" alt=""></a>
                <h6 class="logged-fullname"><?php echo e(Auth::user()->name); ?></h6>
                <p><?php echo e(Auth::user()->email); ?></p>
              </div>
              <hr>
              <ul class="list-unstyled user-profile-nav">
                <li><a href="<?php echo e(url('/auth/change-password')); ?>"><i class="icon ion-ios-person"></i> <?php echo e(__('general.change_password')); ?></a></li>
                <li><a href="<?php echo e(url('/auth/logout')); ?>"><i class="icon ion-power"></i> <?php echo e(__('general.logout')); ?></a></li>
              </ul>
            </div><!-- dropdown-menu -->
        </div><!-- dropdown -->
    </nav>
</div>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/navbar.blade.php ENDPATH**/ ?>