<div class="modal fade" id="salary_request_approve_all" data-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('general.salary_request_approve')); ?></h5>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/salary/approve/salary/all')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="jobs_shift_id" value="<?php echo e($jobs_shift->id); ?>"/>
          <input type="hidden" name="is_approve_salary" value="requested"/>

          <div class="form-group">
            <label><?php echo e(__('general.file')); ?></label>
            <?php echo $__env->make('layout.upload_multiple_photo', [
              "isArrImageUsingID" => true,
              "column" => "file_name",
              "form_name" => "file[]",
              "accept" => "*/*",
              "id" => "salary_image_all",
              "url_image" => "/image/check-log/document",
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          <div>
            <button type="submit" class="btn btn-primary" >Submit</button>
            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    $(document).ready(function() {
      
    })
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/modal/salary_request_approve_all.blade.php ENDPATH**/ ?>