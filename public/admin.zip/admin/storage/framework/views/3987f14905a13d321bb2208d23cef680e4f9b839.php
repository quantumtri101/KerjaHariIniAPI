<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  </head>
  <body>
    <div>
      <p class="text-center"><?php echo e($jobs->id); ?></p>
      <p class="text-center"><?php echo e($jobs->name); ?> @ <?php echo e($jobs_shift->start_date->formatLocalized('%d %B %Y')); ?></p>
      <div class="visible-print text-center">
        <img src="data:image/png;base64, <?php echo $qr_code; ?>"/>
      </div>
    </div>
  </body>
</html>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/print_qr.blade.php ENDPATH**/ ?>