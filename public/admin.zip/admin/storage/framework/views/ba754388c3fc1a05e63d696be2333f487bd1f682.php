<div class="row">
  <div class="col-12">
    <div class="row">
      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.id')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->jobs->id); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->jobs->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.sub_category_name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->jobs->sub_category->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.event_name')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->jobs->event->name); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.num_people_required')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->jobs->num_people_required); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.start_date')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->start_date->formatLocalized('%d %B %Y %H:%M')); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>

      <div class="col-12 col-lg-6">
        <div class="form-group">
          <label for="exampleInputEmail1"><?php echo e(__('general.end_date')); ?></label>
          <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e($jobs_shift->end_date->formatLocalized('%d %B %Y %H:%M')); ?>" aria-describedby="emailHelp" disabled>
        </div>
      </div>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    <?php if($jobs_shift->end_date->add(2, 'hours') >= \Carbon\Carbon::now() && Auth::user()->type->name == "RO" && $allow_manual_check_log): ?>
    <button data-toggle="modal" data-target="#check_log_manual" class="btn btn-primary mr-3"><?php echo e(__('general.manual_check_log')); ?></button>
    <?php endif; ?>

    <a class="btn btn-primary" target="_blank" href="<?php echo e(url('/jobs/print-qr?id='.$jobs_shift->jobs->id)); ?>"><?php echo e(__('general.print_qr')); ?></a>
  </div>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/check_log/component/general_info.blade.php ENDPATH**/ ?>