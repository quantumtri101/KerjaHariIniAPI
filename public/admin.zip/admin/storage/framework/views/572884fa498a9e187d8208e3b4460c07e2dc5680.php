<div>

  <div class="mt-3 table-responsive">
    <table class="table" id="datatable<?php echo e($id); ?>">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.id')); ?></th>
          <?php if(Auth::user()->type->name == "admin"): ?>
            <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.company_name')); ?></th>
          <?php endif; ?>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.event_name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_approve')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.num_staff')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_on_app')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_work')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.first_shift_start_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.first_shift_end_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_open_close')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.status_urgent')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.action')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/index_table.blade.php ENDPATH**/ ?>