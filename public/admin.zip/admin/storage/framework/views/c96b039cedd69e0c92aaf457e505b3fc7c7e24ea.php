<div>
  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th><?php echo e(__('general.image')); ?></th>
        <th><?php echo e(__('general.sub_category')); ?></th>
        <th><?php echo e(__('general.action')); ?></th>
      </tr>
    </thead>
    <tbody id="table_body_sub_category">
      
    </tbody>
  </table>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    var arr_sub_category = []

    async function manage_arr_sub_category(){
      var str = ""
      if(arr_sub_category.length > 0){
        for(let x in arr_sub_category){
          str += `
            <tr>
              <td><img src="${arr_sub_category[x].url_image}" style="width: 10rem"/></td>
              <td>${arr_sub_category[x].name}</td>
              <td>
                <button class="btn btn-primary" type="button" onclick="on_edit(${x})"><?php echo e(__("general.edit")); ?></button>
                <button class="btn btn-danger" type="button" onclick="on_delete(${x})"><?php echo e(__("general.delete")); ?></button>
              </td>
            </tr>
          `

          await getBase64(arr_sub_category[x].image_data, (response) => {
            arr_sub_category[x].image = response
          })
        }
      }
      else
        str += `
          <tr>
            <td colspan="5" class="text-center"><?php echo e(__('general.no_data')); ?></td>
          </tr>
        `
      $('#please_wait_modal').modal('show')
      setTimeout(() => {
        $('#please_wait_modal').modal('hide')
        $('#arr_sub_category').val(JSON.stringify(arr_sub_category))
        $('#table_body_sub_category').html(str)
      }, 1000);
    }
  </script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/sub_category/component/multiple/table.blade.php ENDPATH**/ ?>