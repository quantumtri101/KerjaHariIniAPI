

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.jobs'),
      __($lang_file.'.detail'),
      __($lang_file.'.edit'),
    ] : [
      __('general.jobs'),
      __($lang_file.'.add'),
    ],
    "title" => __($lang_file.'.choose_staff'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => __($lang_file.'.choose_staff'),
    'include_back_button' => false,
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" id="jobsForm" class="mt-3" action="<?php echo e(url('/jobs/choose-staff')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="jobs_id" value="<?php echo e(Request::get('id')); ?>"/>
        

        <div class="mb-3">
          <h5 id="remaining_user"><?php echo e(__('general.remaining_user')); ?>: <?php echo e(count($jobs->application_online)); ?> / <?php echo e(__('general.num_person', ['num' => $jobs->num_people_required])); ?></h5>
        </div>

        <div id="wizard1">
          <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3><?php echo e(__('general.'.$tab["id"])); ?></h3>
            <section>
              <?php echo $__env->make($tab["component"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </form>
    </div>
  </div>

  

  <?php $__env->startPush('script'); ?>
    <script>
      var arr_application = []
      function on_tab_clicked(id){
        localStorage.setItem('menu', id)
      }
      
      function remaining_user(){
        var total_user_applied = arr_user_regular.length + arr_user_casual.length + arr_user_casual_all.length
        var num_people_required = <?php echo e($jobs->num_people_required); ?>

        $('#remaining_user').html(`
          <?php echo e(__('general.remaining_user')); ?>: ${total_user_applied} / ${num_people_required} <?php echo e(__('general.person')); ?>

        `)

        if(num_people_required > total_user_applied){
          $(`.btn-regular-set-applied`).attr('disabled', false)
          $(`.btn-casual-set-applied`).attr('disabled', false)
          $(`.btn-casual-all-set-applied`).attr('disabled', false)
        }
        else{
          $(`.btn-regular-set-applied`).attr('disabled', true)
          $(`.btn-casual-set-applied`).attr('disabled', true)
          $(`.btn-casual-all-set-applied`).attr('disabled', true)
        }
      }
      
      $(document).ready(async() => {
        var menu = await get_menu_detail()
          
        localStorage.setItem('menu', menu)
          
        $('#' + menu + '-tab').addClass('active')
        $('#' + menu).addClass('show active')

        
        <?php $__currentLoopData = $jobs->application_online; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          arr_application.push({
            id: '<?php echo e($application->id); ?>',
            user_id: '<?php echo e($application->user_id); ?>',
          })
          <?php if($application->user_type == "regular"): ?>
            arr_user_regular.push({
              id: '<?php echo e($application->user->id); ?>',
              jobs_application_id: '<?php echo e($application->id); ?>',
            })
            manage_arr_user_regular('<?php echo e($application->user->id); ?>')
          <?php elseif($application->user_type == "casual"): ?>
            arr_user_casual.push({
              id: '<?php echo e($application->user->id); ?>',
              jobs_application_id: '<?php echo e($application->id); ?>',
            })
            manage_arr_user_casual('<?php echo e($application->user->id); ?>')
          <?php else: ?>
            arr_user_casual_all.push({
              id: '<?php echo e($application->user->id); ?>',
              jobs_application_id: '<?php echo e($application->id); ?>',
            })
            manage_arr_user_casual_all('<?php echo e($application->user->id); ?>')
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        var wizard = $('#wizard1').steps({
          headerTag: 'h3',
          bodyTag: 'section',
          // autoFocus: true,
          titleTemplate: '<span class="number">#index#</span> <span class="title">#title#</span>',
          onStepChanged: function (event, currentIndex, priorIndex) {
            if(currentIndex == 0)
              $('#btn-cancel').removeClass('d-none')
            else
              $('#btn-cancel').addClass('d-none')
          },
          onFinished: function (event, currentIndex) {
            var menu1 = -1
            var message = ""
            var message_user_casual = check_user_casual()
            var message_user_regular = check_user_regular()
            var message_user_casual_all = check_user_casual_all()

            if(message_user_casual != ""){
              message = message_user_casual
              menu1 = 0
            }
            else if(message_user_regular != ""){
              message = message_user_regular
              menu1 = 1
            }
            if(message_user_casual_all != ""){
              message = message_user_casual_all
              menu1 = 2
            }

            if(message !== ""){
              $("#wizard1-t-"+menu1).get(0).click();
              // $('#' + menu1 + '-tab').tab('show')
              notify_user(message, event)
              return
            }
            back_page(false)
            
            var total_user_applied = arr_user_regular.length + arr_user_casual.length + arr_user_casual_all.length
            var num_people_required = <?php echo e($jobs->num_people_required); ?>


            $('#jobsForm').trigger('submit')
            // if(total_user_applied < num_people_required)
            //   $('#notify_auto_live_choose_staff').modal('show')
            // else
            //   $('#notify_not_live_choose_staff').modal('show')
          }
        });
        var $input = $('<a class="btn btn-outline-secondary" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>');
        $input.prependTo($('.actions'));
        $('.actions').addClass('d-flex')
        $('ul[aria-label="Pagination"]').addClass('w-100 ml-3')

        <?php echo $__env->yieldPushContent('afterScript'); ?>
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/choose_staff.blade.php ENDPATH**/ ?>