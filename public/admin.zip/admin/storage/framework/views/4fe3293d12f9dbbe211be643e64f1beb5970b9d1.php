<div>
  

  <?php if(count($jobs->image) > 0): ?>
    <div class="row">
      <?php $__currentLoopData = $jobs->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-lg-3 mt-3">
          <img src="<?php echo e(url('/image/jobs').'?file_name='.$image->file_name); ?>" style="width: 10rem"/>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php else: ?>
    <div class="d-flex align-items-center justify-content-center">
      <p class="m-0"><?php echo e(__('general.no_image')); ?></p>
    </div>
  <?php endif; ?>
</div><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/list_image.blade.php ENDPATH**/ ?>