<div class="modal fade" id="check_log_upload" data-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><?php echo e(__('general.check_log_upload')); ?></h5>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(url('/check-log/requested')); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="jobs_shift_id" value="<?php echo e($jobs_shift->id); ?>"/>
          <input type="hidden" name="user_id" id="check_log_upload_user_id"/>

          <div class="form-group">
            <label><?php echo e(__('general.file')); ?></label>
            <?php echo $__env->make('layout.upload_multiple_photo', [
              "column" => "file_name",
              "form_name" => "file[]",
              "accept" => "*/*",
              "id" => "check_log_document_image",
              "url_image" => "/image/check-log/document",
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          <div>
            <button type="submit" class="btn btn-primary" >Submit</button>
            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/casual_freelance/admin/resources/views/layout/modal/check_log_request_approve.blade.php ENDPATH**/ ?>