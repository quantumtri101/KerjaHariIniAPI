<div class="">
  <input type="hidden" id="arr_skill" name="arr_skill"/>
  <div class="row">
    <div class="col-12 col-lg-4">
      <?php echo $__env->make('user.customer.oncall.component.action.skill.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-12 col-lg-8 mt-3 mt-lg-0">
      <?php echo $__env->make('user.customer.oncall.component.action.skill.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    function check_skill(){
      var message = ""
      if(arr_skill.length == 0)
        message = "<?php echo e(__('general.skill_empty')); ?>"
      return message
    }
  </script>
  <?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/user/customer/oncall/component/action/skill_info.blade.php ENDPATH**/ ?>