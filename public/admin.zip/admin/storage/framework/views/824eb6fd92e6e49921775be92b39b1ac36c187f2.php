

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.company'),
      __('company.detail'),
    ],
    "title" => __('company.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => __('company.detail'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="mt-3">
    <ul class="nav nav-pills" id="detailTab" role="tablist">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link border-0" id="<?php echo e($tab["id"]); ?>-tab" data-toggle="tab" data-target="#<?php echo e($tab["id"]); ?>" type="button" role="tab" onclick="on_tab_clicked('<?php echo e($tab["id"]); ?>')" aria-controls="<?php echo e($tab["id"]); ?>" aria-selected="true"><?php echo e(__('general.'.$tab["id"])); ?></button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="mt-3 d-none" id="filter_container">
      <?php echo $__env->make('layout.reservation_filter',[
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <!-- Tab panes -->
    <div class="tab-content mt-3" id="pills-detailTabContent">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane" id="<?php echo e($tab["id"]); ?>" role="tabpanel" aria-labelledby="<?php echo e($tab["id"]); ?>-tab">
        <div class="card">
          <div class="card-body">
            <?php echo $__env->make($tab["component"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      function on_tab_clicked(id){
        localStorage.setItem('menu', id)
      }
      
      $(document).ready(async() => {
        var menu = await get_menu_detail()
          
        localStorage.setItem('menu', menu)
          
        $('#' + menu + '-tab').addClass('active')
        $('#' + menu).addClass('show active')
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/company/detail.blade.php ENDPATH**/ ?>