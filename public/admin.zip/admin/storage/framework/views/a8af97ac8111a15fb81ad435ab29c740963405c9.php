<div class="row">
  <div class="col-12">
    <div class="form-group d-none">
      <label><?php echo e(__('general.status_publish')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="is_publish" value="<?php echo e($jobs->is_publish); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="is_publish" value="1" <?php echo e(!empty($jobs) && $jobs->is_publish == 1 ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-publish">
        <label class="form-check-label" for="radio-publish">
          <?php echo e(__('general.publish')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="is_publish" value="0" <?php echo e(!empty($jobs) && $jobs->is_publish == 0 ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-not_publish">
        <label class="form-check-label" for="radio-not_publish">
          <?php echo e(__('general.not_publish')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.status_urgent')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="is_urgent" value="<?php echo e($jobs->is_urgent); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="is_urgent" value="1" <?php echo e(!empty($jobs) && $jobs->is_urgent == 1 ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-urgent">
        <label class="form-check-label" for="radio-urgent">
          <?php echo e(__('general.urgent')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="is_urgent" value="0" <?php echo e(!empty($jobs) && $jobs->is_urgent == 0 ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-not_urgent">
        <label class="form-check-label" for="radio-not_urgent">
          <?php echo e(__('general.not_urgent')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.type')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="staff_type" value="<?php echo e($jobs->staff_type); ?>" />
      <?php endif; ?>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="staff_type" value="closed" <?php echo e(!empty($jobs) && $jobs->staff_type == "closed" ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-closed">
        <label class="form-check-label" for="radio-closed">
          <?php echo e(__('general.closed')); ?>

        </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="radio" name="staff_type" value="open" <?php echo e(!empty($jobs) && $jobs->staff_type == "open" ? 'checked' : ''); ?> <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="radio-open">
        <label class="form-check-label" for="radio-open">
          <?php echo e(__('general.open')); ?>

        </label>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.province')); ?></label>
      <select name="province_id" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="province_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_province')); ?></option>
        <?php $__currentLoopData = $arr_province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($province->id); ?>" <?php echo e(!empty($jobs) && $province->id == $jobs->city->province->id ? 'selected' : ''); ?>><?php echo e($province->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.city')); ?></label>
      <select name="city_id" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="city_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_city')); ?></option>
        <?php $__currentLoopData = $arr_city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($city->id); ?>" <?php echo e(!empty($jobs) && $city->id == $jobs->city->id ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.event')); ?></label>
      <select name="event_id" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="event_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_event')); ?></option>
        <?php $__currentLoopData = $arr_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($event->id); ?>" <?php echo e(!empty($jobs) && $event->id == $jobs->event->id ? 'selected' : ''); ?>><?php echo e($event->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group d-none">
      <label><?php echo e(__('general.department')); ?></label>
      <select name="company_position_id" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="department_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_department')); ?></option>
        <?php $__currentLoopData = $arr_company_position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($company_position->id); ?>" <?php echo e(!empty($jobs) && !empty($jobs->company_position) && $company_position->id == $jobs->company_position->id ? 'selected' : ''); ?>><?php echo e($company_position->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.category')); ?></label>
      <select name="category_id" <?php echo e(((!empty($jobs) && $jobs->allow_edit) || empty($jobs)) && empty(Auth::user()->company) ? '' : 'readonly'); ?> id="category_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_category')); ?></option>
        <?php $__currentLoopData = $arr_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($category->id); ?>" <?php echo e((!empty(Auth::user()->company) && Auth::user()->company->category->id == $category->id) || (empty(Auth::user()->company) && !empty($jobs) && $category->id == $jobs->sub_category->category->id) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.sub_category')); ?></label>
      <select name="sub_category_id" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?> id="sub_category_id" class="form-control">
        <option value=""><?php echo e(__('general.choose_sub_category')); ?></option>
        <?php $__currentLoopData = $arr_sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($sub_category->id); ?>" <?php echo e(!empty($jobs) && $sub_category->id == $jobs->sub_category->id ? 'selected' : ''); ?>><?php echo e($sub_category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.name')); ?></label>
      <input type="text" name="name" id="name" class="form-control" value="<?php echo e(!empty($jobs) ? $jobs->name : ''); ?>" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>/>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.description')); ?></label>
      <textarea name="description" class="form-control" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>><?php echo e(!empty($jobs) ? $jobs->description : ''); ?></textarea>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.num_people_required')); ?></label>
      <div class="input-group">
        <input type="text" name="num_people_required" id="num_people_required" class="form-control" value="<?php echo e(!empty($jobs) ? number_format($jobs->num_people_required, 0, ',', '.') : '0'); ?>" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>/>
        <div class="input-group-prepend">
          <span class="input-group-text" id="basic-addon1">Person</span>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.list_staff_approve')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="arr_approve_json" value="<?php echo e(json_encode($jobs->arr_approve)); ?>" />
      <?php endif; ?>
      <div class="row">
        <div class="col-12">
          <div class="input-group">
            <input type="text" name="num_staff_approve" id="num_staff_approve" class="form-control" value="<?php echo e(!empty($jobs) ? number_format(count($jobs->approve), 0, ',', '.') : '0'); ?>" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>/>
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1">Person</span>
            </div>
          </div>
        </div>

        <div class="col-12 mt-3">
          <div id="approve_container">
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.list_staff_approve_check_log')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="arr_approve_check_log_json" value="<?php echo e(json_encode($jobs->arr_approve_check_log)); ?>" />
      <?php endif; ?>
      <div class="row">
        <div class="col-12">
          <div class="input-group">
            <input type="text" name="num_staff_approve_check_log" id="num_staff_approve_check_log" class="form-control" value="<?php echo e(!empty($jobs) ? number_format(count($jobs->approve_check_log), 0, ',', '.') : '0'); ?>" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>/>
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1">Person</span>
            </div>
          </div>
        </div>

        <div class="col-12 mt-3">
          <div id="approve_check_log_container">
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.list_staff_approve_salary')); ?></label>
      <?php if(!empty($jobs) && !$jobs->allow_edit): ?>
        <input type="hidden" name="arr_approve_salary_json" value="<?php echo e(json_encode($jobs->arr_approve_salary)); ?>" />
      <?php endif; ?>
      <div class="row">
        <div class="col-12">
          <div class="input-group">
            <input type="text" name="num_staff_approve_salary" id="num_staff_approve_salary" class="form-control" value="<?php echo e(!empty($jobs) ? number_format(count($jobs->approve_salary), 0, ',', '.') : '0'); ?>" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'readonly'); ?>/>
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1">Person</span>
            </div>
          </div>
        </div>

        <div class="col-12 mt-3">
          <div id="approve_salary_container">
          </div>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label><?php echo e(__('general.image')); ?></label>
      <?php echo $__env->make('layout.upload_multiple_photo_step', [
        "column" => "file_name",
        "form_name" => "image[]",
        "data" => $jobs,
        "id" => "jobs_image",
        "url_image" => "/image/jobs",
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="col-12 d-flex mt-3">
    
  </div>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    function check_general(){
      var num_staff_approve = $('#num_staff_approve').val()
      var num_staff_approve_check_log = $('#num_staff_approve_check_log').val()
      var num_staff_approve_salary = $('#num_staff_approve_salary').val()
      var message = ""
      var arr_staff = []
      <?php $__currentLoopData = $arr_staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        arr_staff.push({
          id: '<?php echo e($staff->id); ?>',
          name: '<?php echo e($staff->name); ?>',
        })
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      var counter_approve = 0
      var counter_approve_salary = 0
      var counter_approve_check_log = 0
      for(let x = 0; x < num_staff_approve; x++){
        if($('#people_approve'+x).val() == "")
          break
        counter_approve++
      }
      for(let x = 0; x < num_staff_approve_salary; x++){
        if($('#people_approve_salary'+x).val() == "")
          break
        counter_approve_salary++
      }
      for(let x = 0; x < num_staff_approve_check_log; x++){
        if($('#people_approve_check_log'+x).val() == "")
          break
        counter_approve_check_log++
      }
      
      // if(!$('#radio-publish').is(':checked') && !$('#radio-not_publish').is(':checked'))
      //   message = "<?php echo e(__('general.status_publish_not_choosen')); ?>"
      if(!$('#radio-urgent').is(':checked') && !$('#radio-not_urgent').is(':checked'))
        message = "<?php echo e(__('general.status_urgent_not_choosen')); ?>"
      else if($('#event_id').val() == "")
        message = "<?php echo e(__('general.event_not_choosen')); ?>"
      // else if($('#department_id').val() == "")
      //   message = "<?php echo e(__('general.department_not_choosen')); ?>"
      else if($('#category_id').val() == "")
        message = "<?php echo e(__('general.category_not_choosen')); ?>"
      else if($('#sub_category_id').val() == "")
        message = "<?php echo e(__('general.sub_category_not_choosen')); ?>"
      else if($('#name').val() == "")
        message = "<?php echo e(__('general.name_empty')); ?>"
      else if($('#num_people').val() == "" || $('#num_people').val() == "0")
        message = "<?php echo e(__('general.num_people_empty')); ?>"
      else if($('#num_people_required').val() == "" || $('#num_people_required').val() == "0")
        message = "<?php echo e(__('general.num_people_required_empty')); ?>"
      else if($('#num_staff_approve').val() == "" || $('#num_staff_approve').val() == "0")
        message = "<?php echo e(__('general.num_staff_approve_empty')); ?>"
      else if($('#num_staff_approve_check_log').val() == "" || $('#num_staff_approve_check_log').val() == "0")
        message = "<?php echo e(__('general.num_staff_approve_check_log_empty')); ?>"
      else if($('#num_staff_approve_salary').val() == "" || $('#num_staff_approve_salary').val() == "0")
        message = "<?php echo e(__('general.num_staff_approve_salary_empty')); ?>"
      else if(counter_approve < num_staff_approve)
        message = "<?php echo e(__('general.list_staff_approve_not_choosen')); ?>"
      else if(counter_approve_salary < num_staff_approve_salary)
        message = "<?php echo e(__('general.list_staff_approve_salary_not_choosen')); ?>"
      else if(counter_approve_check_log < num_staff_approve_check_log)
        message = "<?php echo e(__('general.list_staff_approve_check_log_not_choosen')); ?>"
      return message
    }

    async function get_sub_category(category_id){
      var response = await request('<?php echo e(url("/api/sub-category")); ?>?is_publish=1&category_id=' + category_id)
      if(response != null){
        if(response.status === "success"){
          var str = `
            <option value=""><?php echo e(__('general.choose_sub_category')); ?></option>
          `
          for(let sub_category of response.data)
            str += `<option value="${sub_category.id}">${sub_category.name}</option>`
          // console.log(response.data)
          $('#sub_category_id').html(str)
        }
      }
    }

    async function get_city(province_id){
      var response = await request('<?php echo e(url("/api/city/all")); ?>?is_publish=1&province_id=' + province_id)
      if(response != null){
        if(response.status === "success"){
          var str = `
            <option value=""><?php echo e(__('general.choose_city')); ?></option>
          `
          for(let city of response.data)
            str += `<option value="${city.id}">${city.name}</option>`
          // console.log(response.data)
          $('#city_id').html(str)
        }
      }
    }

    function manage_arr_staff_approve(){
      var num_staff = $('#num_staff_approve').val()
      var arr_approve = []
      var arr_staff = []
      <?php if(!empty($jobs)): ?>
        <?php $__currentLoopData = $jobs->approve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          arr_approve.push({
            id: '<?php echo e($approve->id); ?>',
            user_id: '<?php echo e($approve->user_id); ?>',
          })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php $__currentLoopData = $arr_staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var data = {
          id: '<?php echo e($staff->id); ?>',
          name: '<?php echo e($staff->name); ?>',
        }
        
        <?php if(!empty($staff->sub_category)): ?>
          data.sub_category = {
            id: '<?php echo e($staff->sub_category->id); ?>',
            name: '<?php echo e($staff->sub_category->name); ?>',
          }
        <?php endif; ?>

        arr_staff.push(data)
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      var str = '<div class="row">'
      for(let x = 0; x < num_staff; x++){
        var user_id = ""
        if(arr_approve.length > 0 && arr_approve[x] != null)
          user_id = arr_approve[x].user_id

        str += `
          <div class="col-3 mb-3">
            <div class="d-flex align-items-center">
              <label class="m-0">${x+1}.</label>
              <select name="arr_people_approve[]" class="form-control ml-1 staff_approve" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="people_approve${x}">
                <option value=""><?php echo e(__('general.choose_staff')); ?></option>
                `
        for(let staff of arr_staff){
          flag = false
          for(let y in arr_approve){
            if(y < x && arr_approve[y].user_id == staff.id){
              flag = true
              break
            }
          }
          if(flag)
            continue

          str += `<option value="${staff.id}" ${user_id !== '' && user_id === staff.id ? 'selected' : ''}>${staff.name} ${staff.sub_category != null ? "("+staff.sub_category.name+")" : ""}</option>`
        }
        str += `
              </select>
            </div>
          </div>
        `
      }
      str += '</div>'
      $('#approve_container').html(str)
    }

    function manage_arr_staff_approve_salary(){
      var num_staff = $('#num_staff_approve_salary').val()
      var arr_approve = []
      var arr_staff = []
      <?php if(!empty($jobs)): ?>
        <?php $__currentLoopData = $jobs->approve_salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve_salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          arr_approve.push({
            id: '<?php echo e($approve_salary->id); ?>',
            user_id: '<?php echo e($approve_salary->user_id); ?>',
          })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php $__currentLoopData = $arr_staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var data = {
          id: '<?php echo e($staff->id); ?>',
          name: '<?php echo e($staff->name); ?>',
        }
        
        <?php if(!empty($staff->sub_category)): ?>
          data.sub_category = {
            id: '<?php echo e($staff->sub_category->id); ?>',
            name: '<?php echo e($staff->sub_category->name); ?>',
          }
        <?php endif; ?>

        arr_staff.push(data)
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      var str = '<div class="row">'
      for(let x = 0; x < num_staff; x++){
        var user_id = ""
        if(arr_approve.length > 0 && arr_approve[x] != null)
          user_id = arr_approve[x].user_id

        str += `
          <div class="col-3 mb-3">
            <div class="d-flex align-items-center">
              <label class="m-0">${x+1}.</label>
              <select name="arr_people_approve_salary[]" class="form-control ml-1 staff_approve_salary" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="people_approve_salary${x}">
                <option value=""><?php echo e(__('general.choose_staff')); ?></option>
                `
        for(let staff of arr_staff){
          flag = false
          for(let y in arr_approve){
            if(y < x && arr_approve[y].user_id == staff.id){
              flag = true
              break
            }
          }
          if(flag)
            continue

          str += `<option value="${staff.id}" ${user_id !== '' && user_id === staff.id ? 'selected' : ''}>${staff.name} ${staff.sub_category != null ? "("+staff.sub_category.name+")" : ""}</option>`
        }
        str += `
              </select>
            </div>
          </div>
        `
      }
      str += '</div>'
      $('#approve_salary_container').html(str)
    }

    function manage_arr_staff_approve_check_log(){
      var num_staff = $('#num_staff_approve_check_log').val()
      var arr_approve = []
      var arr_staff = []
      <?php if(!empty($jobs)): ?>
        <?php $__currentLoopData = $jobs->approve_check_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve_check_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          arr_approve.push({
            id: '<?php echo e($approve_check_log->id); ?>',
            user_id: '<?php echo e($approve_check_log->user_id); ?>',
          })
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php $__currentLoopData = $arr_staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      var data = {
          id: '<?php echo e($staff->id); ?>',
          name: '<?php echo e($staff->name); ?>',
        }
        
        <?php if(!empty($staff->sub_category)): ?>
          data.sub_category = {
            id: '<?php echo e($staff->sub_category->id); ?>',
            name: '<?php echo e($staff->sub_category->name); ?>',
          }
        <?php endif; ?>

        arr_staff.push(data)
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      var str = '<div class="row">'
      for(let x = 0; x < num_staff; x++){
        var user_id = ""
        if(arr_approve.length > 0 && arr_approve[x] != null)
          user_id = arr_approve[x].user_id

        str += `
          <div class="col-3 mb-3">
            <div class="d-flex align-items-center">
              <label class="m-0">${x+1}.</label>
              <select name="arr_people_approve_check_log[]" class="form-control ml-1 staff_approve_check_log" <?php echo e((!empty($jobs) && $jobs->allow_edit) || empty($jobs) ? '' : 'disabled'); ?> id="people_approve_check_log${x}">
                <option value=""><?php echo e(__('general.choose_staff')); ?></option>
                `
        for(let staff of arr_staff){
          flag = false
          for(let y in arr_approve){
            if(y < x && arr_approve[y].user_id == staff.id){
              flag = true
              break
            }
          }
          if(flag)
            continue

          str += `<option value="${staff.id}" ${user_id !== '' && user_id === staff.id ? 'selected' : ''}>${staff.name} ${staff.sub_category != null ? "("+staff.sub_category.name+")" : ""}</option>`
        }
        str += `
              </select>
            </div>
          </div>
        `
      }
      str += '</div>'
      $('#approve_check_log_container').html(str)
    }
    
    $(document).ready(() => {
      
    })
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
var setTimeout = null

<?php if(!empty($jobs)): ?>
  <?php $__currentLoopData = $jobs->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    arr_url_image.push('<?php echo e(url("/image/jobs?file_name=".$image->file_name)); ?>')
    arr_file_name.push('<?php echo e($image->file_name); ?>')
    arr_id.push('<?php echo e($image->id); ?>')
    arr_image.push(null)
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  on_change_multiple_image()

  $('#num_staff_approve').val(<?php echo e(count($jobs->approve)); ?>)
  manage_arr_staff_approve()
  $('#num_staff_approve_salary').val(<?php echo e(count($jobs->approve_salary)); ?>)
  manage_arr_staff_approve_salary()
  $('#num_staff_approve_check_log').val(<?php echo e(count($jobs->approve_check_log)); ?>)
  manage_arr_staff_approve_check_log()
<?php endif; ?>

$('#category_id').change(() => {
  this.get_sub_category($('#category_id').val())
})
$('#province_id').change(() => {
  this.get_city($('#province_id').val())
})
$('#submit').click((e) => {
  
})
$('#num_people_required').keyup(() => {
  $('#num_people_required').val(to_currency_format($('#num_people_required').val()))
})
$('.staff_approve').change(() => {
  manage_arr_staff_approve()
})
$('#num_staff_approve').keyup(() => {
  $('#num_staff_approve').val(to_currency_format($('#num_staff_approve').val()))
  
  if(setTimeout != null)
    clearTimeout(setTimeout)

  setTimeout = window.setTimeout(() => {
    var num_staff_approve = to_currency_format($('#num_staff_approve').val())
    <?php if(!empty($jobs)): ?>
      var arr_approve = []
      <?php $__currentLoopData = $jobs->approve; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        arr_approve.push({
          id: '<?php echo e($approve->id); ?>',
          user_id: '<?php echo e($approve->user_id); ?>',
          status_approve: '<?php echo e($approve->status_approve); ?>',
        })
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      if(arr_approve[num_staff_approve - 1] != null && arr_approve[num_staff_approve - 1].status == "approved")
        num_staff_approve = arr_approve.length
    <?php endif; ?>
    
    $('#num_staff_approve').val(num_staff_approve)
    manage_arr_staff_approve()
  }, 100)
})
$('.staff_approve_salary').change(() => {
  manage_arr_staff_approve_salary()
})
$('#num_staff_approve_salary').keyup(() => {
  $('#num_staff_approve_salary').val(to_currency_format($('#num_staff_approve_salary').val()))
  
  if(setTimeout != null)
    clearTimeout(setTimeout)

  setTimeout = window.setTimeout(() => {
    var num_staff_approve_salary = to_currency_format($('#num_staff_approve_salary').val())
    <?php if(!empty($jobs)): ?>
      var arr_approve_salary = []
      <?php $__currentLoopData = $jobs->approve_salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve_salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        arr_approve_salary.push({
          id: '<?php echo e($approve_salary->id); ?>',
          user_id: '<?php echo e($approve_salary->user_id); ?>',
          status_approve: '<?php echo e($approve_salary->status_approve); ?>',
        })
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      if(arr_approve_salary[num_staff_approve_salary - 1] != null && arr_approve_salary[num_staff_approve_salary - 1].status == "approved")
        num_staff_approve_salary = arr_approve_salary.length
    <?php endif; ?>
    
    $('#num_staff_approve_salary').val(num_staff_approve_salary)
    manage_arr_staff_approve_salary()
  }, 100)
})
$('.staff_approve_check_log').change(() => {
  manage_arr_staff_approve_check_log()
})
$('#num_staff_approve_check_log').keyup(() => {
  $('#num_staff_approve_check_log').val(to_currency_format($('#num_staff_approve_check_log').val()))
  
  if(setTimeout != null)
    clearTimeout(setTimeout)

  setTimeout = window.setTimeout(() => {
    var num_staff_approve_check_log = to_currency_format($('#num_staff_approve_check_log').val())
    <?php if(!empty($jobs)): ?>
      var arr_approve_check_log = []
      <?php $__currentLoopData = $jobs->approve_check_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approve_check_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        arr_approve_check_log.push({
          id: '<?php echo e($approve_check_log->id); ?>',
          user_id: '<?php echo e($approve_check_log->user_id); ?>',
          status_approve: '<?php echo e($approve_check_log->status_approve); ?>',
        })
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      if(arr_approve_check_log[num_staff_approve_check_log - 1] != null && arr_approve_check_log[num_staff_approve_check_log - 1].status == "approved")
        num_staff_approve_check_log = arr_approve_check_log.length
    <?php endif; ?>
    
    $('#num_staff_approve_check_log').val(num_staff_approve_check_log)
    manage_arr_staff_approve_check_log()
  }, 100)
})
$('#person_in_charge_phone').keyup(() => {
  $('#person_in_charge_phone').val(phone_validation($('#person_in_charge_phone').val()))
})
$('#interviewer_phone').keyup(() => {
  $('#interviewer_phone').val(phone_validation($('#interviewer_phone').val()))
})
$('#radio-company').click(() => {
  $('#company_layout').removeClass('d-none')
  $('#event_layout').addClass('d-none')
})
$('#radio-event').click(() => {
  $('#company_layout').addClass('d-none')
  $('#event_layout').removeClass('d-none')
})
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/action/general_info.blade.php ENDPATH**/ ?>