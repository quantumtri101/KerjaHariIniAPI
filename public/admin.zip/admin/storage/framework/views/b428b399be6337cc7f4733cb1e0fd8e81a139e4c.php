

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => [
      __('general.jobs'),
    ],
    "title" => __('jobs.title'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
  <div class="d-flex justify-content-between align-items-center">
    <h5 class="h3 mb-0 text-gray-800 font-weight-bold mb-3"><?php echo e(__('jobs.title')); ?></h5>

    

    
  </div>

  <div class="mt-3">
    <ul class="nav nav-pills" id="detailTab" role="tablist">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
          <button class="nav-link border-0" id="<?php echo e($tab["id"]); ?>-tab" data-toggle="tab" data-target="#<?php echo e($tab["id"]); ?>" type="button" role="tab" onclick="on_tab_clicked('<?php echo e($tab["id"]); ?>', '<?php echo e($tab["url"]); ?>')" aria-controls="<?php echo e($tab["id"]); ?>" aria-selected="true"><?php echo e(__('general.'.$tab["id"])); ?></button>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="mt-3 d-none" id="filter_container">
      <?php echo $__env->make('layout.reservation_filter',[
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <!-- Tab panes -->
    <div class="tab-content mt-3" id="pills-detailTabContent">
      <?php $__currentLoopData = $arr_tab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="tab-pane" id="<?php echo e($tab["id"]); ?>" role="tabpanel" aria-labelledby="<?php echo e($tab["id"]); ?>-tab">
        <div class="card">
          <div class="card-body">
            <?php echo $__env->make($tab["component"], [
              "url" => $tab["url"],
              "id" => $tab["id"],
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <div class="d-block d-lg-none">
    <a class="btn btn-primary" href="<?php echo e(url('/jobs/action')); ?>"  onclick="save_current_page('<?php echo e(__('jobs.title')); ?>')"><?php echo e(__('general.add')); ?></a>

    <div class="list-group mt-3">
      <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-group-item d-block pd-y-20 rounded-top-0">
          <div class="d-flex justify-content-between align-items-center tx-12 mg-b-10">
            <a href="" class="tx-info"><?php echo e($data->sub_category->name); ?></a>
            <span><?php echo e($data->created_at->formatLocalized('%d %B %Y')); ?></span>
          </div><!-- d-flex -->
          <h6 class="lh-3 mg-b-10"><a href="" class="tx-inverse hover-primary"><?php echo e($data->name); ?></a></h6>
          <div>
            <a class="btn btn-primary" onclick="save_current_page('<?php echo e(__('jobs.title')); ?>')" href="<?php echo e(url('/jobs/detail')); ?>?id=<?php echo e($data->id); ?>")><?php echo e(__('general.detail')); ?></a>
            <?php if((Auth::user()->type->name == "admin" || Auth::user()->type->name == "RO") && $data->status == 'open'): ?>
              <a class="btn btn-danger ml-3" href="#!" onclick="alertDelete('<?php echo e(url('/jobs/delete')); ?>?id=<?php echo e($data->id); ?>')">Delete</a>
            <?php endif; ?>
            <?php if($data->status_approve == "not_yet_approved"): ?>
              <div class="mt-3">
                <form method="post" action="<?php echo e(url('/jobs/approve/change-approve')); ?>" class="d-inline-block">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="jobs_id" value="<?php echo e($data->id); ?>"/>
                  <input type="hidden" name="status_approve" value="approved"/>
                  <button class="btn btn-primary">Approve</button>
                </form>

                <a class="btn btn-danger ml-3" href="#!" onclick="showDeclineModal('<?php echo e($data->id); ?>')">Decline</a>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

<?php echo $__env->make('layout.modal.scanQR_OTS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.jobs_decline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.publish_date_choose_staff', [
  "type" => "index",
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  function showDeclineModal(jobs_id){
    $('#jobs_decline_jobs_id').val(jobs_id)
    $('#jobs_decline_modal').modal('show')
  }

  function showPublishDateModal(data){
    

    shift_start_date = moment(data.shift[0].start_date, "YYYY-MM-DD HH:mm:ss")
    shift_end_date = moment(data.shift[0].end_date, "YYYY-MM-DD HH:mm:ss")
    
    publish_date_jobs_id = data.id
    publish_start_date()
    publish_end_date()
    $('#publish_date_choose_staff').modal('show')
  }

  function showScanQROTSModal(jobs_id){
    $('#scan_qr_ots_jobs_id').val(jobs_id)
    $('#scan_qr_ots_modal').modal('show')
  }

  function addModal(){
    save_current_page("<?php echo e(__('jobs.title')); ?>")
    location.href = "<?php echo e(url('/jobs/action')); ?>"
  }

  var arr_datatable = []
  function init_datatable(id, url){
    if(arr_datatable[id] != null)
      arr_datatable[id].destroy()

    var arr_button = []
    var arr_column = []
    var filter = ""
    <?php if(Auth::user()->type->name == "admin" || Auth::user()->type->name == "RO"): ?>
      arr_button.push(
        {
          className: 'btn btn-primary',   
          text : "<?php echo e(__('general.add')); ?>",
          action: function ( e, dt, node, config ) {
            save_current_page("<?php echo e(__('jobs.title')); ?>")
            location.href = "<?php echo e(url('/jobs/action')); ?>"
          },
          init: function(api, node, config) {
            $(node).removeClass('dt-button')
          },
        }
      )
    <?php endif; ?>

    <?php if(Auth::user()->type->name == "RO" || Auth::user()->type->name == "staff"): ?>
      arr_column.push(
        {"data" : "id", name: "id"},
        {"data" : "event_name", name: "event.name"},
        {"data" : "name", name: "name"},
        {"data" : "status_approve", name: "is_approve"},
        {"data" : "num_staff", name: "is_approve"},
        {"data" : "status_on_app", name: "is_live_app"},
        {"data" : "status_work", name: "is_approve"},
        {"data" : "shift_start_date_format", name: "jobs_shift.start_date"},
        {"data" : "shift_end_date_format", name: "jobs_shift.end_date"},
        {"data" : "status_format", name: "status"},
        {"data" : "status_urgent", name: "is_urgent"},
        {"data" : "action", "orderable" : false},
      )
    <?php else: ?>
      arr_column.push(
        {"data" : "id", name: "id"},
        {"data" : "company_name", name: "company.name"},
        {"data" : "event_name", name: "event.name"},
        {"data" : "name", name: "name"},
        {"data" : "status_approve", name: "is_approve"},
        {"data" : "num_staff", name: "is_approve"},
        {"data" : "status_on_app", name: "is_live_app"},
        {"data" : "status_work", name: "is_approve"},
        {"data" : "shift_start_date_format", name: "jobs_shift.start_date"},
        {"data" : "shift_end_date_format", name: "jobs_shift.end_date"},
        {"data" : "status_format", name: "status"},
        {"data" : "status_urgent", name: "is_urgent"},
        {"data" : "action", "orderable" : false},
      )
    <?php endif; ?>

    arr_datatable[id] = $('#datatable' + id).DataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: '<"toolbar">frtip',
      buttons: arr_button,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : url,
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "desc"]],
      // deferLoading: 2,
      "columns" : arr_column,
      "columnDefs" : [
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var start_date = moment(row.shift[0].start_date, "YYYY-MM-DD HH:mm:ss")

            var str = ""
            str += '<div style="">'
              if(row.is_approve == 1 && row.status == "open" && row.num_people_required > row.application.length)
                str += `<button type="button" class="btn btn-primary mr-1" onclick="showScanQROTSModal('${row.id}')">
                  <?php echo e(__('general.scan_qr_ots')); ?>

                </button>`
              // if(row.is_approve == 1 && row.status == "open")
                str += `<a class="btn btn-primary mr-1" target="_blank" href="<?php echo e(url('/jobs/export/pdf')); ?>?id=${row.id}">
                  <?php echo e(__('general.export_pdf')); ?>

                </a>`
              str += `<a class="btn btn-primary mb-1" onclick="save_current_page('<?php echo e(__('jobs.title')); ?>')" href="<?php echo e(url('/jobs/detail')); ?>?id=${row.id}")><?php echo e(__('general.detail')); ?></a>`

              <?php if(Auth::user()->type->name == "admin" || Auth::user()->type->name == "RO"): ?>
                if(row.status == "open")
                  str += `<a class="btn btn-danger ml-1 mb-1" href="#!" onclick="alertDelete('<?php echo e(url('/jobs/delete')); ?>?id=${row.id}')">Delete</a>`
                if((row.is_approve == 0 || row.is_approve == 1) && row.staff_type == "closed" && row.num_people_required > row.application_online.length)
                  str += `<a class="btn btn-primary ml-1 mb-1" onclick="save_current_page('<?php echo e(__('jobs.title')); ?>')" href="<?php echo e(url('/jobs/choose-staff')); ?>?id=${row.id}")><?php echo e(__('general.choose_user')); ?></a>`
              <?php endif; ?>

              if(row.status_approve == "not_yet_approved")
                str += `
                  <div class="mt-3 mb-1">
                    <form method="post" action="<?php echo e(url('/jobs/approve/change-approve')); ?>" class="d-inline-block">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="jobs_id" value="${row.id}"/>
                      <input type="hidden" name="status_approve" value="approved"/>
                      <button class="btn btn-primary">Approve</button>
                    </form>

                    <a class="btn btn-danger ml-1" href="#!" onclick="showDeclineModal('${row.id}')">Decline</a>
                  </div>
                `

              <?php if(Auth::user()->type->name == "admin" || Auth::user()->type->name == "RO"): ?>
                if(row.is_approve == 1){
                  shift_start_date = moment(row.shift[0].start_date, "YYYY-MM-DD HH:mm:ss")
                  shift_end_date = moment(row.shift[0].end_date, "YYYY-MM-DD HH:mm:ss")
                  
                  if(moment().add(1, 'd').isBefore(shift_end_date)){
                    if(row.is_live_app == 1)
                      str += `
                        <form method="post" action="<?php echo e(url('/jobs/change-live')); ?>" class="d-inline-block ml-1">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="jobs_id" value="${row.id}"/>
                          <input type="hidden" name="is_live_app" value="0"/>
                          <button class="btn btn-primary"><?php echo e(__('general.change_not_live')); ?></button>
                        </form>
                      `
                    else
                      str += `
                        <form method="post" class="jobsForm" key="${row.id}" action="<?php echo e(url('/jobs/change-live')); ?>" class="d-inline-block ml-1">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="jobs_id" value="${row.id}"/>
                          <input type="hidden" name="publish_start_date" class="publish_start_date" key="${row.id}"/>
                          <input type="hidden" name="publish_end_date" class="publish_end_date" key="${row.id}"/>
                        </form>
                        <button type="button" class="btn btn-primary" onclick='showPublishDateModal(${JSON.stringify(row)})'><?php echo e(__('general.change_live')); ?></button>
                      `
                  }
                }
              <?php endif; ?>
            str += '</div>'
            return str
          },
        },
      ]
    })

    $('.toolbar').addClass('d-inline-block')
    $('.toolbar').html(`
      <div class="d-flex align-items-center">
        <a class="btn btn-primary" href="#" onclick="addModal()"><?php echo e(__('general.add')); ?></a>
        <div class="form-group ml-3 mb-0 d-flex align-items-center">
          <select id="filter" class="form-control">
            <option value=""><?php echo e(__('general.no_filter')); ?></option>
            <?php $__currentLoopData = $arr_filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($filter['id']); ?>"><?php echo e(__('general.'.$filter['id'])); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
    `)

    $('#filter').change(function() {
      filter = $('#filter').val()
      arr_datatable[id].ajax.url(url + (url.includes('?') ? '&filter=' : '?filter=') + filter)
      arr_datatable[id].ajax.reload()
      // console.log(datatable.api().ajax.url())
    })
  }

  function on_tab_clicked(id, url){
    localStorage.setItem('menu', id)
    localStorage.setItem('url', url)
    this.init_datatable(id, url)
  }
  
  $(document).ready(async() => {
    var menu = await get_menu_detail("on_going")
    var url = await localStorage.getItem('url')
      
    localStorage.setItem('menu', menu)
    this.init_datatable(menu, url != null ? url : '<?php echo $arr_tab[0]["url"]; ?>')
      
    $('#' + menu + '-tab').addClass('active')
    $('#' + menu).addClass('show active')

    
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/index.blade.php ENDPATH**/ ?>