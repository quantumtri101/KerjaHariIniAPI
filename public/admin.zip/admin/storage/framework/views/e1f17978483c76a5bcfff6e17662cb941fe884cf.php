

<?php $__env->startSection('breadcrumb'); ?>
  <?php echo $__env->make('layout.custom_breadcrumb', [
    "arr" => Request::has('id') ? [
      __('general.sub_category'),
      __('sub_category.edit'),
    ] : [
      __('general.sub_category'),
      __('sub_category.add'),
    ],
    "title" => Request::has('id') ? __('sub_category.edit') : __('sub_category.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.custom_navigation', [
    "title" => Request::has('id') ? __('sub_category.edit') : __('sub_category.add'),
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="card mt-3">
    <div class="card-body position-relative">
      <form method="post" class="mt-3" action="<?php echo e(url(Request::has('id') ? '/master/sub-category/edit' : '/master/sub-category')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if(Request::has('id')): ?>
          <input type="hidden" name="id" value="<?php echo e(Request::get('id')); ?>"/>
        <?php endif; ?>

        <div class="form-group">
          <label><?php echo e(__('general.image')); ?></label>
          <?php echo $__env->make('layout.upload_photo', [
            "column" => "file_name",
            "form_name" => "image",
            "data" => $sub_category,
            "id" => "image",
            "url_image" => "/image/sub-category",
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.category')); ?></label>
          <select name="category_id" required class="form-control">
            <?php $__currentLoopData = $arr_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>" <?php echo e(!empty($sub_category) && $sub_category->category->id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label><?php echo e(__('general.name')); ?></label>
          <input type="text" required name="name" class="form-control" value="<?php echo e(!empty($sub_category) ? $sub_category->name : ''); ?>"/>
        </div>

        <div class="form-group" >
          <a class="btn btn-outline-dark" type="button" onclick="back_page()"><?php echo e(__('general.cancel')); ?></a>
          <button class="btn btn-primary" id="submit"><?php echo e(__('general.submit')); ?></button>
        </div>
      </form>
    </div>
  </div>

  <?php $__env->startPush('script'); ?>
    <script>
      $(document).ready(() => {
        $('#submit').click((e) => {
          
        })
      })
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/master/sub_category/action.blade.php ENDPATH**/ ?>