<div>
  <table class="table table-bordered">
    <thead>
      <tr>
        
        <th><?php echo e(__('general.name')); ?></th>
        <?php if((!empty($jobs) && $jobs->allow_edit) || empty($jobs)): ?>
          <th><?php echo e(__('general.action')); ?></th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody id="table_body_qualification">
      
    </tbody>
  </table>
</div>

<?php $__env->startPush('script'); ?>
  <script>
    var arr_qualification = []

    async function manage_arr_qualification(){
      var str = ""
      if(arr_qualification.length > 0){
        for(let x in arr_qualification){
          str += `
            <tr>
              <td>${arr_qualification[x].name}</td>
              <?php if((!empty($jobs) && $jobs->allow_edit) || empty($jobs)): ?>
                <td>
                  <button class="btn btn-primary" type="button" onclick="on_edit(${x})"><?php echo e(__("general.edit")); ?></button>
                  <button class="btn btn-danger" type="button" onclick="on_delete(${x})"><?php echo e(__("general.delete")); ?></button>
                </td>
              <?php endif; ?>
            </tr>
          `
        }
      }
      else
        str += `
          <tr>
            <td colspan="5" class="text-center"><?php echo e(__('general.no_data')); ?></td>
          </tr>
        `

      $('#arr_qualification').val(JSON.stringify(arr_qualification))
      $('#table_body_qualification').html(str)
    }

    $(document).ready(() => {
      
    })
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('afterScript'); ?>
<?php if(!empty($jobs)): ?>
  <?php $__currentLoopData = $jobs->qualification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    arr_qualification.push({
      id: '<?php echo e($qualification->id); ?>',
      status_publish: '<?php echo e(__("general.".($qualification->is_publish == 1 ? 'publish' : 'not_publish'))); ?>',
      is_publish: '<?php echo e($qualification->is_publish); ?>',
      name: '<?php echo e($qualification->name); ?>',
    })
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

manage_arr_qualification()
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/jobs/component/action/qualification/table.blade.php ENDPATH**/ ?>