<div>
  <?php if((Auth::user()->type->name == "RO" || Auth::user()->type->name == "admin") && !$already_requested_all): ?>
    <button class="btn btn-primary" data-toggle="modal" data-target="#check_log_upload_all">Request All to Client</button>
  <?php elseif(Auth::user()->type->name != "RO" && Auth::user()->type->name != "admin"): ?>
    <?php if($allow_approve_check_log): ?>
    <div>
      <form method="POST" class="d-inline-block" action="<?php echo e(url('/jobs/shift/approve')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($jobs_shift->id); ?>"/>
        <input type="hidden" name="approve_type" value="per_staff"/>
        <button class="btn btn-primary" <?php echo e($jobs_shift->approve_type != "none" ? 'disabled' : ''); ?>><?php echo e(__('general.approve_per_staff')); ?></button>
      </form>
      <form method="POST" class="d-inline-block" action="<?php echo e(url('/jobs/shift/approve')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($jobs_shift->id); ?>"/>
        <input type="hidden" name="approve_type" value="all"/>
        <button class="btn btn-primary" <?php echo e($jobs_shift->approve_type != "none" ? 'disabled' : ''); ?>><?php echo e(__('general.approve_all')); ?></button>
      </form>
    </div>
    <?php endif; ?>
  <?php endif; ?>
  <div class="mt-3 table-responsive">
    <table class="table w-100" id="list_check_log_datatable">
      <thead>
        <tr>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.name')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.type')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.gender')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.id_no')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.check_in_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.check_out_date')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.decline_reason')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.approval')); ?></th>
          <th class="border-b-2 dark:border-dark-5 whitespace-nowrap"><?php echo e(__('general.action')); ?></th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<?php echo $__env->make('layout.modal.edit_check_log_date', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.check_log_request_approve', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.check_log_request_approve_all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modal.decline_check_log', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
  var jobs_datatable = null

  function approvedAction(data){
    jobsShiftMinDate = moment('<?php echo e($jobs_shift->start_date->formatLocalized("%d-%m-%Y %H:%M")); ?>', 'DD-MM-YYYY HH:mm')
    jobsShiftMaxDate = moment('<?php echo e($jobs_shift->end_date->formatLocalized("%d-%m-%Y %H:%M")); ?>', 'DD-MM-YYYY HH:mm')
    $('#checkindatetimepicker').val(data.check_in2_at_format)
    $('#checkoutdatetimepicker').val(data.check_out2_at_format)
    $('#check_log_date_user_id').val(data.user.id)
    $('#edit_check_log_date').modal('show')

    init_check_in_date()
    init_check_out_date()
  }

  function requestApprovedAction(data){
    $('#check_log_upload_user_id').val(data.user_id)
    $('#check_log_upload').modal('show')
  }

  function requestApprovedAllAction(data){
    $('#check_log_upload_user_id').val(data.user_id)
    $('#check_log_upload').modal('show')
  }

  function declinedAction(data){
    $('#check_log_decline_user_id').val(data.user.id)
    $('#check_log_decline_jobs_shift_id').val('<?php echo e($jobs_shift->id); ?>')
    $('#check_log_decline_modal').modal('show')
  }

  function downloadDocument(data){
    for(let x in data.document){
      setTimeout(() => {
        window.open("<?php echo e(url('/check-log/document/download')); ?>?id=" + data.document[x].id, "_blank")
      }, 100 * x);
    }
  }

  $(document).ready(function () {
    jobs_datatable = $('#list_check_log_datatable').DataTable({
      "processing" : true,
      "serverSide" : true,
      bLengthChange: false,
      responsive: true,
      dom: 'Bfrtip',
      buttons: [
        // {
        //   className: 'btn btn-primary',   
        //   text : "<?php echo e(__('general.add')); ?>",
        //   action: function ( e, dt, node, config ) {
        //     save_current_page("<?php echo e(__('check_log.title')); ?>")
        //     location.href = "<?php echo e(url('/check-log/action')); ?>"
        //   },
        //   init: function(api, node, config) {
        //     $(node).removeClass('dt-button')
        //   },
        // },
        {
          className: 'btn btn-primary',   
          text : "<?php echo e(__('general.export_excel')); ?>",
          action: function ( e, dt, node, config ) {
            location.href = "<?php echo e(url('/check-log/export/shift/excel').'?id='.$jobs_shift->id); ?>"
          },
          init: function(api, node, config) {
            $(node).removeClass('dt-button')
          },
        },
        {
          className: 'btn btn-primary',   
          text : "<?php echo e(__('general.export_pdf')); ?>",
          action: function ( e, dt, node, config ) {
            location.href = "<?php echo e(url('/check-log/export/shift/pdf').'?id='.$jobs_shift->id); ?>"
          },
          init: function(api, node, config) {
            $(node).removeClass('dt-button')
          },
        },
      ],
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
      },
      "ajax" : {
        url : "<?php echo e(url('api/check-log')); ?>?api_type=check_in&jobs_shift_id=<?php echo e($jobs_shift->id); ?>",
        type : "GET",
        dataType : "json",
        headers : {
          "content-type": "application/json",
          "accept": "application/json",
          "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        },
      },
      "order" : [[0, "asc"]],
      // deferLoading: 2,
      "columns" : [
        {"data" : "user_name", name: "user.name"},
        {"data" : "type_name", name: "type.name"},
        {"data" : "gender", name: "resume.gender"},
        {"data" : "id_no", name: "resume.id_no"},
        {"data" : "check_in_at_format", name: "date"},
        {"data" : "check_out_at_format", name: "date"},
        {"data" : "decline_reason", name: "decline_reason"},
        {"data" : "action", "orderable" : false},
        {"data" : "action", "orderable" : false},
      ],
      "columnDefs" : [
        {
          targets: -2,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var json = JSON.stringify(row)
            
            var str = ""
            str += '<div style="width: auto">'
              <?php if(Auth::user()->type->name == "RO" || Auth::user()->type->name == "admin"): ?>
                <?php if($jobs_shift->start_date < \Carbon\Carbon::now()): ?>
                  if(row.is_approve_check_log == "not_yet_requested" || row.is_approve_check_log == "declined")
                    str += `
                      <button class="btn btn-primary" onclick='approvedAction(${json})'>Edit</button>
                      <button class="btn btn-primary" onclick='requestApprovedAction(${json})'>Request to Client</button>
                    `
                  else
                    str += `<p class="m-0">${row.is_approve_check_log_format}</p>`
                <?php else: ?>
                  str += `<p class="m-0">${row.is_approve_check_log_format}</p>`
                <?php endif; ?>
              <?php else: ?>
                <?php if($allow_approve_check_log): ?>
                  <?php if($jobs_shift->approve_type != "none"): ?>
                    if(row.is_approve_check_log == 'requested')
                      str += `
                        <form method="POST" action="<?php echo e(url('/check-log/approve')); ?>" class="d-inline-block">
                          <?php echo csrf_field(); ?>
                          <input type="hidden" name="jobs_shift_id" value="<?php echo e($jobs_shift->id); ?>"/>
                          <input type="hidden" name="user_id" id="user_id" value="${row.user_id}"/>
                          <input type="hidden" name="is_approve" value="approved"/>
                          <button class="btn btn-primary" >Approved</button>
                        </form>
                        <button class="btn btn-primary" onclick='declinedAction(${json})'>Decline</button>
                      `
                    else
                      str += `<p class="m-0">${row.is_approve_check_log_format}</p>`
                  <?php else: ?>
                    str += `<p class="m-0">${row.is_approve_check_log_format}</p>`
                  <?php endif; ?>
                <?php else: ?>
                  str += `<p class="m-0">${row.is_approve_check_log_format}</p>`
                <?php endif; ?>
              <?php endif; ?>
            str += '</div>'
            return str
          },
        },
        {
          targets: -1,
          data: null,
          sorting: false,
          render: function(data, type, row, meta) {
            var json = JSON.stringify(row)
            
            var str = ""
            str += '<div style="width: auto">'
              if(row.latitude != null && row.longitude != null)
                str += `<a href="<?php echo e(url('/check-log/maps')); ?>?id=${row.id}" onclick="save_current_page('<?php echo e(__('check_log.detail')); ?>')" class="btn btn-primary mr-1" >View Maps</a>`
              if(row.document.length > 0)
                str += `<button class="btn btn-primary mr-1" onclick='downloadDocument(${json})'><?php echo e(__('general.download_all_file')); ?></button>`
            str += '</div>'
            return str
          },
        },
      ]
    })
  })
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/casual_freelance/admin/resources/views/check_log/component/list_check_log.blade.php ENDPATH**/ ?>